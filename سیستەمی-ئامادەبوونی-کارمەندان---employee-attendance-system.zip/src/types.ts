export type ShiftType = 'ڕۆژ' | 'شەو' | 'تایبەت';

export interface Department {
  id: number;
  name: string;
  password?: string;
  createdAt?: string;
}

export interface Shift {
  id: number;
  deptId: number;
  name: string;
  code: string;
  hours: string;
}

export interface Employee {
  id: number;
  deptId: number;
  name: string;
  empCode: string;
  shiftType: string;
  hours: string;
  phone?: string;
  note?: string;
}

export type AttendanceStatus = 'present' | 'absent';

export interface EmployeeAttendance {
  id?: number;
  year: number;
  month: number; // 1-12
  day: number;   // 1-31
  employeeId: number;
  status: AttendanceStatus;
  note?: string;
}

export interface UserSession {
  role: 'admin' | 'dept';
  deptId?: number;
  deptName?: string;
}

export interface AbsenceDateDetail {
  year: number;
  month: number;
  day: number;
  formattedDate: string;
  monthName: string;
  weekday: string;
  shiftType?: string;
  hours?: string;
  note?: string;
}

export interface AbsentEmployeeRecord {
  employee: Employee;
  deptName: string;
  totalAbsences: number;
  periodAbsences: number;
  absenceDates: AbsenceDateDetail[];
}
