import React, { useState, useEffect, useMemo } from 'react';
import { 
  Department, 
  Shift, 
  Employee, 
  EmployeeAttendance, 
  UserSession 
} from './types';
import { 
  loadDepartments, 
  saveDepartments, 
  loadShifts, 
  saveShifts, 
  loadEmployees, 
  saveEmployees, 
  loadAttendance, 
  saveAttendance, 
  loadAdminPassword, 
  saveAdminPassword,
  INITIAL_DEPARTMENTS,
  INITIAL_SHIFTS,
  INITIAL_EMPLOYEES,
  generateInitialAttendance
} from './lib/storage';
import { STORAGE_KEYS } from './lib/constants';
import { Topbar } from './components/Topbar';
import { LoginScreen } from './components/LoginScreen';
import { AdminAbsenceTab } from './components/AdminAbsenceTab';
import { CalendarView } from './components/CalendarView';
import { AllDepartmentsModal } from './components/AllDepartmentsModal';
import { DayModal } from './components/DayModal';
import { DepartmentsModal } from './components/DepartmentsModal';
import { EmployeesModal } from './components/EmployeesModal';
import { BulkAddModal } from './components/BulkAddModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  // Global Data State
  const [departments, setDepartments] = useState<Department[]>(() => loadDepartments());
  const [shifts, setShifts] = useState<Shift[]>(() => loadShifts());
  const [employees, setEmployees] = useState<Employee[]>(() => loadEmployees());
  const [attendanceList, setAttendanceList] = useState<EmployeeAttendance[]>(() => loadAttendance());
  const [adminPassword, setAdminPassword] = useState<string>(() => loadAdminPassword());

  // User Session State (Login)
  const [userSession, setUserSession] = useState<UserSession | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SESSION);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Admin Active Tab: 'absence' | 'calendar' | 'alldepts'
  const [activeAdminTab, setActiveAdminTab] = useState<'absence' | 'calendar' | 'alldepts'>('absence');

  // Calendar State
  const [currentDeptId, setCurrentDeptId] = useState<number | null>(() => {
    return departments[0]?.id || 1;
  });
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1);

  // Modals State
  const [dayModalState, setDayModalState] = useState<{
    isOpen: boolean;
    year: number;
    month: number;
    day: number;
  }>({ isOpen: false, year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: 1 });

  const [isDeptsModalOpen, setIsDeptsModalOpen] = useState(false);
  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false);
  const [employeeToEdit, setEmployeeToEdit] = useState<Employee | null>(null);
  const [isBulkAddModalOpen, setIsBulkAddModalOpen] = useState(false);
  const [bulkAddTargetDeptId, setBulkAddTargetDeptId] = useState<number | null>(null);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // Toast / sync feedback
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Show Toast helper
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg(null);
    }, 2400);
  };

  // Sync state whenever data updates
  const updateDepartments = (next: Department[]) => {
    setDepartments(next);
    saveDepartments(next);
  };

  const updateShifts = (next: Shift[]) => {
    setShifts(next);
    saveShifts(next);
  };

  const updateEmployees = (next: Employee[]) => {
    setEmployees(next);
    saveEmployees(next);
  };

  const updateAttendance = (next: EmployeeAttendance[]) => {
    setAttendanceList(next);
    saveAttendance(next);
  };

  const updateAdminPassword = (next: string) => {
    setAdminPassword(next);
    saveAdminPassword(next);
  };

  // Login handler
  const handleLoginSuccess = (session: UserSession) => {
    setUserSession(session);
    localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(session));
    if (session.role === 'dept' && session.deptId) {
      setCurrentDeptId(session.deptId);
      setActiveAdminTab('calendar');
    } else {
      setActiveAdminTab('absence'); // Default to the requested Absence Tab for admin!
    }
    showToast('بەخێربێیت ✓');
  };

  // Logout handler
  const handleLogout = () => {
    setUserSession(null);
    localStorage.removeItem(STORAGE_KEYS.SESSION);
  };

  // Set session department if department user
  useEffect(() => {
    if (userSession?.role === 'dept' && userSession.deptId) {
      setCurrentDeptId(userSession.deptId);
    }
  }, [userSession]);

  // Total unique absent employees count for badge
  const absentEmployeesCount = useMemo(() => {
    const absentEmpIds = new Set(
      attendanceList.filter(a => a.status === 'absent').map(a => a.employeeId)
    );
    return absentEmpIds.size;
  }, [attendanceList]);

  // Handlers for Departments
  const handleAddDept = (name: string, password: string) => {
    const newDept: Department = {
      id: Date.now(),
      name,
      password,
      createdAt: new Date().toISOString(),
    };
    const next = [...departments, newDept];
    updateDepartments(next);
    showToast(`بەشی "${name}" زیاد کرا ✓`);
  };

  const handleUpdateDept = (id: number, name: string, password: string) => {
    const next = departments.map(d => d.id === id ? { ...d, name, password } : d);
    updateDepartments(next);
    showToast('گۆڕانکارییەکانی بەش هەڵگیرا ✓');
  };

  const handleDeleteDept = (id: number) => {
    const nextDepts = departments.filter(d => d.id !== id);
    const nextShifts = shifts.filter(s => s.deptId !== id);
    const nextEmployees = employees.filter(e => e.deptId !== id);
    const deletedEmpIds = new Set(employees.filter(e => e.deptId === id).map(e => e.id));
    const nextAttendance = attendanceList.filter(a => !deletedEmpIds.has(a.employeeId));

    updateDepartments(nextDepts);
    updateShifts(nextShifts);
    updateEmployees(nextEmployees);
    updateAttendance(nextAttendance);

    if (currentDeptId === id) {
      setCurrentDeptId(nextDepts[0]?.id || null);
    }
    showToast('بەش سڕایەوە');
  };

  // Handlers for Shifts
  const handleAddShift = (deptId: number, name: string, code: string, hours: string) => {
    const newShift: Shift = {
      id: Date.now(),
      deptId,
      name,
      code,
      hours,
    };
    const next = [...shifts, newShift];
    updateShifts(next);
    showToast(`شەفتی "${name}" زیاد کرا ✓`);
  };

  const handleDeleteShift = (shiftId: number) => {
    const next = shifts.filter(s => s.id !== shiftId);
    updateShifts(next);
    showToast('شەفت سڕایەوە');
  };

  // Handlers for Employees
  const handleSaveEmployee = (empData: Partial<Employee>) => {
    if (empData.id) {
      // Edit existing
      const next = employees.map(e => e.id === empData.id ? { ...e, ...empData } as Employee : e);
      updateEmployees(next);
      showToast('زانیاری کارمەند نوێکرایەوە ✓');
    } else {
      // Add new
      const newEmp: Employee = {
        id: Date.now(),
        deptId: empData.deptId || currentDeptId || 1,
        name: empData.name || '',
        empCode: empData.empCode || String(Math.floor(1000 + Math.random() * 9000)),
        shiftType: empData.shiftType || 'ڕۆژ',
        hours: empData.hours || '08:00 - 16:00',
        phone: empData.phone,
      };
      const next = [...employees, newEmp];
      updateEmployees(next);
      showToast(`کارمەند "${newEmp.name}" زیاد کرا ✓`);
    }
  };

  const handleDeleteEmployee = (empId: number, deptPassword?: string) => {
    const emp = employees.find(e => e.id === empId);
    if (!emp) return;

    if (userSession?.role !== 'admin') {
      const dept = departments.find(d => d.id === emp.deptId);
      if (!dept || dept.password !== deptPassword) {
        showToast('❌ وشەی نهێنی بەش هەڵەیە!');
        return false;
      }
    }

    const nextEmps = employees.filter(e => e.id !== empId);
    const nextAtt = attendanceList.filter(a => a.employeeId !== empId);
    updateEmployees(nextEmps);
    updateAttendance(nextAtt);
    showToast(`کارمەند "${emp.name}" سڕایەوە`);
    return true;
  };

  // Bulk add employees
  const handleBulkAddEmployees = (newEmps: Partial<Employee>[]) => {
    const formatted: Employee[] = newEmps.map((item, index) => ({
      id: Date.now() + index,
      deptId: item.deptId || currentDeptId || 1,
      name: item.name || '',
      empCode: item.empCode || String(Math.floor(1000 + Math.random() * 9000)),
      shiftType: item.shiftType || 'ڕۆژ',
      hours: item.hours || '08:00 - 16:00',
      phone: item.phone,
    }));

    const next = [...employees, ...formatted];
    updateEmployees(next);
    showToast(`✓ ${formatted.length} کارمەند زیاد کران`);
  };

  // Reset to initial sample data
  const handleResetToSampleData = () => {
    const initialAtt = generateInitialAttendance();
    updateDepartments(INITIAL_DEPARTMENTS);
    updateShifts(INITIAL_SHIFTS);
    updateEmployees(INITIAL_EMPLOYEES);
    updateAttendance(initialAtt);
    setCurrentDeptId(INITIAL_DEPARTMENTS[0].id);
    showToast('داتاکان گەڕێندرانەوە بۆ نموونەی سەرەتا ✓');
  };

  // Import full JSON backup
  const handleImportAllData = (data: {
    departments: Department[];
    shifts: Shift[];
    employees: Employee[];
    attendance: EmployeeAttendance[];
  }) => {
    updateDepartments(data.departments);
    updateShifts(data.shifts || []);
    updateEmployees(data.employees);
    updateAttendance(data.attendance);
    if (data.departments.length > 0) {
      setCurrentDeptId(data.departments[0].id);
    }
    showToast('هەموو داتاکان جێگیر کران ✓');
  };

  // Manual sync feedback
  const handleManualSync = () => {
    showToast('داتاکان لەگەڵ بیرگەی ناوخۆیی و کاش هاوکات کران ✓');
  };

  // Open Day Modal helper
  const handleOpenDayModal = (year: number, month: number, day: number) => {
    setDayModalState({ isOpen: true, year, month, day });
  };

  // If not logged in, render Login screen
  if (!userSession) {
    return (
      <LoginScreen
        onLoginSuccess={handleLoginSuccess}
        departments={departments}
        adminPassword={adminPassword}
      />
    );
  }

  const isAdmin = userSession.role === 'admin';

  return (
    <div className="min-h-screen bg-[#f4f5f2] text-[#1f2420] pb-12 font-sans selection:bg-[#dbd80f]/30">
      {/* Navigation & Header */}
      <Topbar
        userSession={userSession}
        activeAdminTab={activeAdminTab}
        setActiveAdminTab={setActiveAdminTab}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onLogout={handleLogout}
        onManualSync={handleManualSync}
        syncStatus={{ text: 'ئامادەیە', color: 'green' }}
        absentCount={absentEmployeesCount}
      />

      {/* Main Container */}
      <main className="max-w-6xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
        {/* If Admin and Absence tab is selected (Requested Feature) */}
        {isAdmin && activeAdminTab === 'absence' && (
          <AdminAbsenceTab
            employees={employees}
            departments={departments}
            attendanceList={attendanceList}
            onOpenDayModal={handleOpenDayModal}
            onUpdateAttendance={updateAttendance}
          />
        )}

        {/* If Admin and All Departments overview is selected */}
        {isAdmin && activeAdminTab === 'alldepts' && (
          <AllDepartmentsModal
            departments={departments}
            employees={employees}
            shifts={shifts}
            onSelectDept={(id) => {
              setCurrentDeptId(id);
              setActiveAdminTab('calendar');
            }}
            onOpenAddEmployeeForDept={(deptId) => {
              setCurrentDeptId(deptId);
              setEmployeeToEdit(null);
              setIsEmployeeModalOpen(true);
            }}
            onOpenBulkAddForDept={(deptId) => {
              setBulkAddTargetDeptId(deptId);
              setIsBulkAddModalOpen(true);
            }}
            onOpenEditEmployee={(empId) => {
              const emp = employees.find(e => e.id === empId);
              if (emp) {
                setEmployeeToEdit(emp);
                setIsEmployeeModalOpen(true);
              }
            }}
          />
        )}

        {/* If Calendar View is selected or if logged in as department supervisor */}
        {(!isAdmin || activeAdminTab === 'calendar') && (
          <CalendarView
            currentDeptId={currentDeptId}
            departments={departments}
            shifts={shifts}
            employees={employees}
            attendanceList={attendanceList}
            selectedYear={selectedYear}
            setSelectedYear={setSelectedYear}
            selectedMonth={selectedMonth}
            setSelectedMonth={setSelectedMonth}
            onSelectDept={(id) => setCurrentDeptId(id)}
            onOpenManageDepts={() => setIsDeptsModalOpen(true)}
            onOpenDayModal={handleOpenDayModal}
            onOpenAddEmployee={() => {
              setEmployeeToEdit(null);
              setIsEmployeeModalOpen(true);
            }}
            onOpenEditEmployee={(empId) => {
              const emp = employees.find(e => e.id === empId);
              if (emp) {
                setEmployeeToEdit(emp);
                setIsEmployeeModalOpen(true);
              }
            }}
            isAdmin={isAdmin}
          />
        )}
      </main>

      {/* Day Attendance Entry Modal */}
      <DayModal
        isOpen={dayModalState.isOpen}
        onClose={() => setDayModalState(prev => ({ ...prev, isOpen: false }))}
        year={dayModalState.year}
        month={dayModalState.month}
        day={dayModalState.day}
        currentDeptId={currentDeptId}
        departments={departments}
        employees={employees}
        attendanceList={attendanceList}
        onSave={updateAttendance}
      />

      {/* Departments Manager Modal */}
      <DepartmentsModal
        isOpen={isDeptsModalOpen}
        onClose={() => setIsDeptsModalOpen(false)}
        departments={departments}
        shifts={shifts}
        onAddDept={handleAddDept}
        onUpdateDept={handleUpdateDept}
        onDeleteDept={handleDeleteDept}
        onAddShift={handleAddShift}
        onDeleteShift={handleDeleteShift}
      />

      {/* Employee Add / Edit Modal */}
      <EmployeesModal
        isOpen={isEmployeeModalOpen}
        onClose={() => setIsEmployeeModalOpen(false)}
        departments={departments}
        currentDeptId={currentDeptId}
        employeeToEdit={employeeToEdit}
        onSaveEmployee={handleSaveEmployee}
        onDeleteEmployee={handleDeleteEmployee}
        isAdmin={isAdmin}
      />

      {/* Bulk Add Employees via JSON Modal */}
      <BulkAddModal
        isOpen={isBulkAddModalOpen}
        onClose={() => setIsBulkAddModalOpen(false)}
        departments={departments}
        currentDeptId={bulkAddTargetDeptId || currentDeptId}
        onBulkAdd={handleBulkAddEmployees}
      />

      {/* Settings Modal (Admin) */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        currentAdminPass={adminPassword}
        onChangeAdminPass={updateAdminPassword}
        onResetToSampleData={handleResetToSampleData}
        departments={departments}
        shifts={shifts}
        employees={employees}
        attendanceList={attendanceList}
        onImportAllData={handleImportAllData}
      />

      {/* Floating Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 bg-[#1f2420] text-white px-5 py-2.5 rounded-full text-xs font-bold shadow-xl animate-in fade-in slide-in-from-bottom-3 duration-200">
          {toastMsg}
        </div>
      )}
    </div>
  );
}
