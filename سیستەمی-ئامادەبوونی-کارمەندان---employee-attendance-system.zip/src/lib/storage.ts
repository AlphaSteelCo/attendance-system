import { Department, Shift, Employee, EmployeeAttendance, AbsentEmployeeRecord, AbsenceDateDetail } from '../types';
import { STORAGE_KEYS, DEFAULT_ADMIN_PASS, KURDISH_MONTHS_SHORT, WEEKDAYS_KURDISH } from './constants';

export const INITIAL_DEPARTMENTS: Department[] = [
  { id: 1, name: 'بەشی ژمێریاری و دارایی', password: '1111' },
  { id: 2, name: 'بەشی کارگێڕی و سەرچاوە مرۆییەکان (HR)', password: '2222' },
  { id: 3, name: 'بەشی تەکنەلۆژیا و ئایتی (IT)', password: '3333' },
  { id: 4, name: 'بەشی چاودێری و پاراستن (Security)', password: '4444' },
  { id: 5, name: 'بەشی فرۆشتن و بەبازاڕکردن', password: '5555' },
];

export const INITIAL_SHIFTS: Shift[] = [
  { id: 1, deptId: 1, name: 'شەفتی بەیانیان', code: 'S-101', hours: '08:00 - 15:30' },
  { id: 2, deptId: 2, name: 'شەفتی ئاسایی', code: 'S-102', hours: '08:30 - 16:00' },
  { id: 3, deptId: 3, name: 'شەفتی تەکنیکی ڕۆژ', code: 'S-201', hours: '08:00 - 17:00' },
  { id: 4, deptId: 3, name: 'شەفتی فریاگوزاری شەو', code: 'S-202', hours: '17:00 - 08:00' },
  { id: 5, deptId: 4, name: 'شەفتی ڕۆژ (12 کاتژمێر)', code: 'SEC-D', hours: '07:00 - 19:00' },
  { id: 6, deptId: 4, name: 'شەفتی شەو (12 کاتژمێر)', code: 'SEC-N', hours: '19:00 - 07:00' },
  { id: 7, deptId: 5, name: 'شەفتی فرۆشتن', code: 'SAL-1', hours: '09:00 - 17:30' },
];

export const INITIAL_EMPLOYEES: Employee[] = [
  // Dept 1: ژمێریاری
  { id: 101, deptId: 1, name: 'ئاراس محەمەد کەریم', empCode: '1001', shiftType: 'ڕۆژ', hours: '08:00 - 15:30', phone: '07501234567' },
  { id: 102, deptId: 1, name: 'پەیمان ئەحمەد حەسەن', empCode: '1002', shiftType: 'ڕۆژ', hours: '08:00 - 15:30', phone: '07507654321' },
  { id: 103, deptId: 1, name: 'ڕێباز عەلی قادر', empCode: '1003', shiftType: 'ڕۆژ', hours: '08:00 - 15:30', phone: '07701122334' },
  
  // Dept 2: کارگێڕی
  { id: 201, deptId: 2, name: 'سۆران عوسمان مەحموود', empCode: '2001', shiftType: 'ڕۆژ', hours: '08:30 - 16:00', phone: '07503344556' },
  { id: 202, deptId: 2, name: 'لانە کامەران ڕەئووف', empCode: '2002', shiftType: 'ڕۆژ', hours: '08:30 - 16:00', phone: '07709988776' },
  { id: 203, deptId: 2, name: 'هیوا تەها جەمیل', empCode: '2003', shiftType: 'ڕۆژ', hours: '08:30 - 16:00', phone: '07512233445' },

  // Dept 3: ئایتی
  { id: 301, deptId: 3, name: 'دانا فەرهاد حوسێن', empCode: '3001', shiftType: 'ڕۆژ', hours: '08:00 - 17:00', phone: '07504455667' },
  { id: 302, deptId: 3, name: 'ڕەوەند بەختیار ساڵح', empCode: '3002', shiftType: 'شەو', hours: '17:00 - 08:00', phone: '07705566778' },
  { id: 303, deptId: 3, name: 'شنۆ نەریمان خالید', empCode: '3003', shiftType: 'ڕۆژ', hours: '08:00 - 17:00', phone: '07516677889' },

  // Dept 4: پاسەوانی و ئەمنی
  { id: 401, deptId: 4, name: 'کاروان زاهیر مەولود', empCode: '4001', shiftType: 'ڕۆژ', hours: '07:00 - 19:00', phone: '07508899001' },
  { id: 402, deptId: 4, name: 'پشتیوان جەمال ئەنوەر', empCode: '4002', shiftType: 'شەو', hours: '19:00 - 07:00', phone: '07702233112' },
  { id: 403, deptId: 4, name: 'سەردار فەتاح شەریف', empCode: '4003', shiftType: 'ڕۆژ', hours: '07:00 - 19:00', phone: '07519988443' },
  { id: 404, deptId: 4, name: 'گۆران بەهرۆز ڕەحیم', empCode: '4004', shiftType: 'شەو', hours: '19:00 - 07:00', phone: '07507788990' },

  // Dept 5: فرۆشتن
  { id: 501, deptId: 5, name: 'نیان عەبدولڕەحمان', empCode: '5001', shiftType: 'ڕۆژ', hours: '09:00 - 17:30', phone: '07505544332' },
  { id: 502, deptId: 5, name: 'شاخەوان عیزەت کەمال', empCode: '5002', shiftType: 'ڕۆژ', hours: '09:00 - 17:30', phone: '07708877665' },
];

export function generateInitialAttendance(): EmployeeAttendance[] {
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  const list: EmployeeAttendance[] = [];

  // Seed sample attendances across multiple months and days
  // Aras (101): 4 absences in current and past months
  list.push(
    { year: currentYear, month: currentMonth, day: 2, employeeId: 101, status: 'absent', note: 'نەخۆشی' },
    { year: currentYear, month: currentMonth, day: 8, employeeId: 101, status: 'absent', note: 'مۆڵەتی نەخۆشی' },
    { year: currentYear, month: currentMonth, day: 15, employeeId: 101, status: 'present' },
    { year: currentYear, month: currentMonth, day: 16, employeeId: 101, status: 'present' },
    { year: currentYear, month: Math.max(1, currentMonth - 1), day: 12, employeeId: 101, status: 'absent', note: 'ئامادەنەبوو بێ ئاگاداری' },
    { year: currentYear, month: Math.max(1, currentMonth - 1), day: 22, employeeId: 101, status: 'absent' }
  );

  // Payman (102): 1 absence
  list.push(
    { year: currentYear, month: currentMonth, day: 5, employeeId: 102, status: 'absent', note: 'مۆڵەتی تایبەت' },
    { year: currentYear, month: currentMonth, day: 6, employeeId: 102, status: 'present' },
    { year: currentYear, month: currentMonth, day: 7, employeeId: 102, status: 'present' }
  );

  // Soran (201): 3 absences
  list.push(
    { year: currentYear, month: currentMonth, day: 3, employeeId: 201, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 4, employeeId: 201, status: 'absent' },
    { year: currentYear, month: Math.max(1, currentMonth - 1), day: 19, employeeId: 201, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 10, employeeId: 201, status: 'present' }
  );

  // Dana (301): 6 absences
  list.push(
    { year: currentYear, month: currentMonth, day: 1, employeeId: 301, status: 'absent', note: 'نەهاتووی لەناکاو' },
    { year: currentYear, month: currentMonth, day: 7, employeeId: 301, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 14, employeeId: 301, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 21, employeeId: 301, status: 'absent' },
    { year: currentYear, month: Math.max(1, currentMonth - 1), day: 9, employeeId: 301, status: 'absent' },
    { year: currentYear, month: Math.max(1, currentMonth - 1), day: 10, employeeId: 301, status: 'absent' }
  );

  // Rawand (302): 2 absences
  list.push(
    { year: currentYear, month: currentMonth, day: 11, employeeId: 302, status: 'absent', note: 'شەفتی شەو نەهات' },
    { year: currentYear, month: currentMonth, day: 12, employeeId: 302, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 13, employeeId: 302, status: 'present' }
  );

  // Karwan (401): 5 absences
  list.push(
    { year: currentYear, month: currentMonth, day: 4, employeeId: 401, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 9, employeeId: 401, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 17, employeeId: 401, status: 'absent' },
    { year: currentYear, month: Math.max(1, currentMonth - 1), day: 5, employeeId: 401, status: 'absent' },
    { year: currentYear, month: Math.max(1, currentMonth - 1), day: 6, employeeId: 401, status: 'absent' }
  );

  // Sardor (403): 3 absences
  list.push(
    { year: currentYear, month: currentMonth, day: 13, employeeId: 403, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 18, employeeId: 403, status: 'absent' },
    { year: currentYear, month: Math.max(1, currentMonth - 1), day: 25, employeeId: 403, status: 'absent' }
  );

  // Shakhawan (502): 2 absences
  list.push(
    { year: currentYear, month: currentMonth, day: 6, employeeId: 502, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 20, employeeId: 502, status: 'absent' },
    { year: currentYear, month: currentMonth, day: 21, employeeId: 502, status: 'present' }
  );

  return list;
}

export function loadDepartments(): Department[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DEPARTMENTS);
    if (!raw) {
      saveDepartments(INITIAL_DEPARTMENTS);
      return INITIAL_DEPARTMENTS;
    }
    const data = JSON.parse(raw);
    if (Array.isArray(data) && data.length > 0) return data;
    return INITIAL_DEPARTMENTS;
  } catch {
    return INITIAL_DEPARTMENTS;
  }
}

export function saveDepartments(depts: Department[]): void {
  localStorage.setItem(STORAGE_KEYS.DEPARTMENTS, JSON.stringify(depts));
}

export function loadShifts(): Shift[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SHIFTS);
    if (!raw) {
      saveShifts(INITIAL_SHIFTS);
      return INITIAL_SHIFTS;
    }
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : INITIAL_SHIFTS;
  } catch {
    return INITIAL_SHIFTS;
  }
}

export function saveShifts(shifts: Shift[]): void {
  localStorage.setItem(STORAGE_KEYS.SHIFTS, JSON.stringify(shifts));
}

export function loadEmployees(): Employee[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EMPLOYEES);
    if (!raw) {
      saveEmployees(INITIAL_EMPLOYEES);
      return INITIAL_EMPLOYEES;
    }
    const data = JSON.parse(raw);
    return Array.isArray(data) && data.length > 0 ? data : INITIAL_EMPLOYEES;
  } catch {
    return INITIAL_EMPLOYEES;
  }
}

export function saveEmployees(emps: Employee[]): void {
  localStorage.setItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(emps));
}

export function loadAttendance(): EmployeeAttendance[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
    if (!raw) {
      const initial = generateInitialAttendance();
      saveAttendance(initial);
      return initial;
    }
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

export function saveAttendance(list: EmployeeAttendance[]): void {
  localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(list));
}

export function loadAdminPassword(): string {
  return localStorage.getItem(STORAGE_KEYS.ADMIN_PASS) || DEFAULT_ADMIN_PASS;
}

export function saveAdminPassword(pass: string): void {
  localStorage.setItem(STORAGE_KEYS.ADMIN_PASS, pass);
}

export function getWeekdayKurdish(year: number, month: number, day: number): string {
  const dow = new Date(year, month - 1, day).getDay(); // 0=Sun
  return WEEKDAYS_KURDISH[dow]?.name || 'ڕۆژ';
}

/**
 * Get all absent employees with detailed breakdown of all their absent days.
 */
export function getAbsentEmployees(
  employees: Employee[],
  departments: Department[],
  attendanceList: EmployeeAttendance[],
  options?: {
    deptId?: number | 'all';
    year?: number | 'all';
    month?: number | 'all';
    searchTerm?: string;
    sortBy?: 'most_absences' | 'least_absences' | 'code' | 'name' | 'dept';
  }
): AbsentEmployeeRecord[] {
  const deptMap = new Map<number, string>();
  departments.forEach(d => deptMap.set(d.id, d.name));

  const records: AbsentEmployeeRecord[] = [];

  for (const emp of employees) {
    if (options?.deptId && options.deptId !== 'all' && emp.deptId !== options.deptId) {
      continue;
    }

    // Filter search by name and code
    if (options?.searchTerm) {
      const term = options.searchTerm.trim().toLowerCase();
      const matchName = emp.name.toLowerCase().includes(term);
      const matchCode = (emp.empCode || '').toLowerCase().includes(term);
      const matchDept = (deptMap.get(emp.deptId) || '').toLowerCase().includes(term);
      if (!matchName && !matchCode && !matchDept) {
        continue;
      }
    }

    // All absences for this employee
    const empAbsences = attendanceList.filter(
      a => a.employeeId === emp.id && a.status === 'absent'
    );

    if (empAbsences.length === 0) {
      continue; // only absence employees as requested
    }

    // Period filtered absences (for count in selected year/month if chosen)
    const periodAbsences = empAbsences.filter(a => {
      if (options?.year && options.year !== 'all' && a.year !== options.year) return false;
      if (options?.month && options.month !== 'all' && a.month !== options.month) return false;
      return true;
    });

    // If month/year filter is specific, only show if they have absences in that period, unless year/month is 'all'
    if ((options?.year !== 'all' && options?.year) || (options?.month !== 'all' && options?.month)) {
      if (periodAbsences.length === 0) continue;
    }

    // Convert dates to detailed objects
    const absenceDates: AbsenceDateDetail[] = empAbsences
      .sort((a, b) => {
        // Sort descending (newest first)
        if (a.year !== b.year) return b.year - a.year;
        if (a.month !== b.month) return b.month - a.month;
        return b.day - a.day;
      })
      .map(a => {
        const monthShort = KURDISH_MONTHS_SHORT[a.month - 1] || `Month ${a.month}`;
        const weekday = getWeekdayKurdish(a.year, a.month, a.day);
        const pad = (n: number) => String(n).padStart(2, '0');
        const formattedDate = `${a.year}/${pad(a.month)}/${pad(a.day)}`;

        return {
          year: a.year,
          month: a.month,
          day: a.day,
          formattedDate,
          monthName: monthShort,
          weekday,
          shiftType: emp.shiftType,
          hours: emp.hours,
          note: a.note,
        };
      });

    records.push({
      employee: emp,
      deptName: deptMap.get(emp.deptId) || 'بەشی نەناسراو',
      totalAbsences: empAbsences.length,
      periodAbsences: periodAbsences.length,
      absenceDates,
    });
  }

  // Sorting
  const sortBy = options?.sortBy || 'most_absences';
  records.sort((a, b) => {
    if (sortBy === 'most_absences') {
      return b.totalAbsences - a.totalAbsences;
    }
    if (sortBy === 'least_absences') {
      return a.totalAbsences - b.totalAbsences;
    }
    if (sortBy === 'code') {
      const codeA = parseInt(a.employee.empCode) || 0;
      const codeB = parseInt(b.employee.empCode) || 0;
      if (codeA && codeB) return codeA - codeB;
      return a.employee.empCode.localeCompare(b.employee.empCode);
    }
    if (sortBy === 'name') {
      return a.employee.name.localeCompare(b.employee.name, 'ckb');
    }
    if (sortBy === 'dept') {
      return a.deptName.localeCompare(b.deptName, 'ckb');
    }
    return 0;
  });

  return records;
}
