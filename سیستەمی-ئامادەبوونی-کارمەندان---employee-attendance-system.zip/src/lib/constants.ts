export const KURDISH_MONTHS = [
  'کStats/Jan - کانوونی دووەم',
  'شوبات/Feb - شوبات',
  'ئازار/Mar - ئازار',
  'نیسان/Apr - نیسان',
  'ئایار/May - ئایار',
  'حوزەیران/Jun - حوزەیران',
  'تەمووز/Jul - تەمووز',
  'ئاب/Aug - ئاب',
  'ئەیلوول/Sep - ئەیلوول',
  'تشرینی یەکەم/Oct - تشرینی یەکەم',
  'تشرینی دووەم/Nov - تشرینی دووەم',
  'کانوونی یەکەم/Dec - کانوونی یەکەم',
];

export const KURDISH_MONTHS_SHORT = [
  'Jan (کانوونی دووەم)',
  'Feb (شوبات)',
  'Mar (ئازار)',
  'Apr (نیسان)',
  'May (ئایار)',
  'Jun (حوزەیران)',
  'Jul (تەمووز)',
  'Aug (ئاب)',
  'Sep (ئەیلوول)',
  'Oct (تشرینی یەکەم)',
  'Nov (تشرینی دووەم)',
  'Dec (کانوونی یەکەم)',
];

export const WEEKDAYS_KURDISH = [
  { name: 'یەکشەممە', short: 'Sun', isWeekend: false },
  { name: 'دووشەممە', short: 'Mon', isWeekend: false },
  { name: 'سێشەممە', short: 'Tue', isWeekend: false },
  { name: 'چوارشەممە', short: 'Wed', isWeekend: false },
  { name: 'پێنجشەممە', short: 'Thu', isWeekend: false },
  { name: 'هەینی', short: 'Fri', isWeekend: true },
  { name: 'شەممە', short: 'Sat', isWeekend: true },
];

export const STORAGE_KEYS = {
  DEPARTMENTS: 'att_departments_v2',
  SHIFTS: 'att_shifts_v2',
  EMPLOYEES: 'att_employees_v2',
  ATTENDANCE: 'att_employee_attendance_v2',
  ADMIN_PASS: 'att_admin_password_v2',
  SESSION: 'att_user_session_v2',
  SUPABASE_URL: 'att_supabase_url',
  SUPABASE_KEY: 'att_supabase_key',
};

export const DEFAULT_ADMIN_PASS = '1234';
