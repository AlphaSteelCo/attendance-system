import React, { useState } from 'react';
import { Department, Shift } from '../types';
import { X, Plus, Trash2, Edit3, Building2, Clock, Key } from 'lucide-react';

interface DepartmentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  departments: Department[];
  shifts: Shift[];
  onAddDept: (name: string, password: string) => void;
  onUpdateDept: (id: number, name: string, password: string) => void;
  onDeleteDept: (id: number) => void;
  onAddShift: (deptId: number, name: string, code: string, hours: string) => void;
  onDeleteShift: (shiftId: number) => void;
}

export const DepartmentsModal: React.FC<DepartmentsModalProps> = ({
  isOpen,
  onClose,
  departments,
  shifts,
  onAddDept,
  onUpdateDept,
  onDeleteDept,
  onAddShift,
  onDeleteShift,
}) => {
  const [newDeptName, setNewDeptName] = useState('');
  const [newDeptPass, setNewDeptPass] = useState('');
  const [editingDeptId, setEditingDeptId] = useState<number | null>(null);

  // Edit fields
  const [editName, setEditName] = useState('');
  const [editPass, setEditPass] = useState('');

  // Add shift state
  const [shiftName, setShiftName] = useState('');
  const [shiftCode, setShiftCode] = useState('');
  const [shiftHours, setShiftHours] = useState('');

  if (!isOpen) return null;

  const handleCreateDept = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeptName.trim() || !newDeptPass.trim()) return;
    onAddDept(newDeptName.trim(), newDeptPass.trim());
    setNewDeptName('');
    setNewDeptPass('');
  };

  const startEdit = (dept: Department) => {
    setEditingDeptId(dept.id);
    setEditName(dept.name);
    setEditPass(dept.password || '');
  };

  const handleSaveEdit = () => {
    if (!editingDeptId || !editName.trim() || !editPass.trim()) return;
    onUpdateDept(editingDeptId, editName.trim(), editPass.trim());
    setEditingDeptId(null);
  };

  const handleAddShiftSubmit = (e: React.FormEvent, deptId: number) => {
    e.preventDefault();
    if (!shiftName.trim()) return;
    onAddShift(deptId, shiftName.trim(), shiftCode.trim() || `S-${Date.now().toString().slice(-3)}`, shiftHours.trim() || '08:00 - 16:00');
    setShiftName('');
    setShiftCode('');
    setShiftHours('');
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-xs">
      <div className="bg-white w-full max-w-xl max-h-[90vh] rounded-t-3xl sm:rounded-2xl p-5 overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-[#e4e6df]">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#2c2c00]" />
            <h3 className="text-base font-extrabold text-[#1f2420]">بەڕێوەبردنی بەش و شەفتەکان</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 space-y-4 py-3 pr-1 pl-1">
          {/* Create New Dept Form */}
          <form onSubmit={handleCreateDept} className="bg-[#f8f9f6] p-3.5 rounded-2xl border border-[#e4e6df] space-y-2.5">
            <h4 className="text-xs font-black text-[#1f2420]">➕ زیادکردنی بەشی نوێ</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                value={newDeptName}
                onChange={(e) => setNewDeptName(e.target.value)}
                placeholder="ناوی بەش (نموونە: بەشی کۆگا)..."
                className="px-3 py-2 bg-white border border-[#e4e6df] rounded-xl text-xs outline-none focus:border-[#dbd80f]"
              />
              <input
                type="password"
                value={newDeptPass}
                onChange={(e) => setNewDeptPass(e.target.value)}
                placeholder="وشەی نهێنی چوونەژوورەوەی بەش..."
                className="px-3 py-2 bg-white border border-[#e4e6df] rounded-xl text-xs outline-none focus:border-[#dbd80f]"
              />
            </div>
            <button
              type="submit"
              disabled={!newDeptName.trim() || !newDeptPass.trim()}
              className="w-full py-2 bg-[#dbd80f] hover:bg-[#c2be0d] disabled:opacity-40 text-xs font-black text-[#2c2c00] rounded-xl transition"
            >
              زیادکردنی بەش
            </button>
          </form>

          {/* List of Departments */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-[#6b7268]">لیستی بەشە تۆمارکراوەکان:</h4>

            {departments.map((dept) => {
              const deptShiftsList = shifts.filter(s => s.deptId === dept.id);
              const isEditing = editingDeptId === dept.id;

              return (
                <div key={dept.id} className="p-3.5 bg-white border border-[#e4e6df] rounded-2xl shadow-xs space-y-3">
                  {isEditing ? (
                    <div className="space-y-2 p-2 bg-amber-50 rounded-xl border border-amber-200">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="px-3 py-1.5 bg-white border border-amber-300 rounded-lg text-xs font-bold"
                          placeholder="ناوی بەش"
                        />
                        <input
                          type="text"
                          value={editPass}
                          onChange={(e) => setEditPass(e.target.value)}
                          className="px-3 py-1.5 bg-white border border-amber-300 rounded-lg text-xs font-bold"
                          placeholder="وشەی نهێنی"
                        />
                      </div>
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setEditingDeptId(null)}
                          className="px-3 py-1 bg-white border border-gray-300 rounded-lg text-xs text-gray-700"
                        >
                          پاشگەزبوونەوە
                        </button>
                        <button
                          type="button"
                          onClick={handleSaveEdit}
                          className="px-4 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold"
                        >
                          هەڵگرتن
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div>
                        <span className="font-black text-sm text-[#1f2420]">{dept.name}</span>
                        <div className="flex items-center gap-2 text-xs text-[#6b7268] mt-0.5">
                          <span className="font-mono bg-gray-100 px-1.5 py-0.2 rounded">
                            🔑 وشەی نهێنی: {dept.password || '****'}
                          </span>
                          <span>•</span>
                          <span>{deptShiftsList.length} شەفت</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => startEdit(dept)}
                          className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-lg text-xs font-bold transition"
                          title="دەستکاریکردنی بەش"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`دڵنیایت لە سڕینەوەی بەشی "${dept.name}"؟`)) {
                              onDeleteDept(dept.id);
                            }
                          }}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg text-xs font-bold transition"
                          title="سڕینەوەی بەش"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Shifts of this dept */}
                  <div className="pt-2 border-t border-gray-100">
                    <div className="flex items-center justify-between text-[11px] font-bold text-[#6b7268] mb-1.5">
                      <span>شەفتەکانی ئەم بەشە:</span>
                    </div>

                    <div className="space-y-1.5 mb-2.5">
                      {deptShiftsList.length === 0 ? (
                        <div className="text-[11px] text-gray-400 italic">هیچ شەفتێک نییە.</div>
                      ) : (
                        deptShiftsList.map(s => (
                          <div key={s.id} className="flex items-center justify-between py-1 px-2.5 bg-[#f8f9f6] rounded-lg text-xs">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-[#1f2420]">{s.name}</span>
                              <span className="text-[11px] text-gray-500 font-mono">({s.code})</span>
                              <span className="text-[11px] text-emerald-800 font-mono bg-emerald-50 px-1.5 py-0.2 rounded">
                                {s.hours}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => onDeleteShift(s.id)}
                              className="text-red-500 hover:text-red-700 text-[11px]"
                              title="سڕینەوەی شەفت"
                            >
                              ✕
                            </button>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Quick Add Shift Form */}
                    <form onSubmit={(e) => handleAddShiftSubmit(e, dept.id)} className="flex items-center gap-1.5">
                      <input
                        type="text"
                        placeholder="ناوی شەفت..."
                        value={shiftName}
                        onChange={(e) => setShiftName(e.target.value)}
                        className="flex-1 py-1 px-2 text-xs bg-[#fafaf8] border border-gray-200 rounded-lg outline-none"
                      />
                      <input
                        type="text"
                        placeholder="کات (7-19)..."
                        value={shiftHours}
                        onChange={(e) => setShiftHours(e.target.value)}
                        className="w-24 py-1 px-2 text-xs bg-[#fafaf8] border border-gray-200 rounded-lg outline-none font-mono"
                      />
                      <button
                        type="submit"
                        className="px-2.5 py-1 bg-gray-900 text-white rounded-lg text-xs font-bold hover:bg-black"
                      >
                        + شەفت
                      </button>
                    </form>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#e4e6df] flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-[#1f2420] text-white text-xs font-bold rounded-xl hover:bg-black transition"
          >
            داخستن
          </button>
        </div>
      </div>
    </div>
  );
};
