import React from 'react';
import { Department, Shift, Employee, EmployeeAttendance } from '../types';
import { KURDISH_MONTHS_SHORT, WEEKDAYS_KURDISH } from '../lib/constants';
import { 
  Calendar as CalendarIcon, 
  ChevronRight, 
  ChevronLeft, 
  Building2, 
  Users, 
  Plus, 
  Clock, 
  CheckCircle2, 
  XCircle,
  Search,
  Sun,
  Moon
} from 'lucide-react';

interface CalendarViewProps {
  currentDeptId: number | null;
  departments: Department[];
  shifts: Shift[];
  employees: Employee[];
  attendanceList: EmployeeAttendance[];
  selectedYear: number;
  setSelectedYear: (y: number) => void;
  selectedMonth: number; // 1-12
  setSelectedMonth: (m: number) => void;
  onSelectDept: (id: number) => void;
  onOpenManageDepts: () => void;
  onOpenDayModal: (year: number, month: number, day: number) => void;
  onOpenAddEmployee: () => void;
  onOpenEditEmployee: (empId: number) => void;
  isAdmin: boolean;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  currentDeptId,
  departments,
  shifts,
  employees,
  attendanceList,
  selectedYear,
  setSelectedYear,
  selectedMonth,
  setSelectedMonth,
  onSelectDept,
  onOpenManageDepts,
  onOpenDayModal,
  onOpenAddEmployee,
  onOpenEditEmployee,
  isAdmin,
}) => {
  const [empSearch, setEmpSearch] = React.useState('');

  const currentDept = departments.find(d => d.id === currentDeptId);
  const deptShifts = shifts.filter(s => s.deptId === currentDeptId);
  const deptEmployees = employees.filter(e => e.deptId === currentDeptId);

  const filteredDeptEmployees = React.useMemo(() => {
    if (!empSearch.trim()) return deptEmployees;
    const term = empSearch.trim().toLowerCase();
    return deptEmployees.filter(
      e => e.name.toLowerCase().includes(term) || (e.empCode || '').toLowerCase().includes(term)
    );
  }, [deptEmployees, empSearch]);

  // Calendar calculations
  const daysInMonth = new Date(selectedYear, selectedMonth, 0).getDate();
  const firstDayOfWeek = new Date(selectedYear, selectedMonth - 1, 1).getDay(); // 0=Sun

  // Attendance summary for each day in this month & department
  const dayStatsMap = React.useMemo(() => {
    const map = new Map<number, { present: number; absent: number }>();
    if (!currentDeptId) return map;

    const deptEmpIds = new Set(deptEmployees.map(e => e.id));

    attendanceList.forEach(a => {
      if (a.year === selectedYear && a.month === selectedMonth && deptEmpIds.has(a.employeeId)) {
        const current = map.get(a.day) || { present: 0, absent: 0 };
        if (a.status === 'present') current.present += 1;
        if (a.status === 'absent') current.absent += 1;
        map.set(a.day, current);
      }
    });
    return map;
  }, [attendanceList, selectedYear, selectedMonth, currentDeptId, deptEmployees]);

  const changeMonth = (delta: number) => {
    let newM = selectedMonth + delta;
    let newY = selectedYear;
    if (newM > 12) {
      newM = 1;
      newY += 1;
    } else if (newM < 1) {
      newM = 12;
      newY -= 1;
    }
    setSelectedMonth(newM);
    setSelectedYear(newY);
  };

  return (
    <div className="space-y-4">
      {/* Department Switcher Bar for Admin */}
      {isAdmin && (
        <div className="bg-white rounded-2xl p-3.5 border border-[#e4e6df] shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1">
            <Building2 className="w-4 h-4 text-[#6b7268]" />
            <span className="text-xs font-bold text-[#6b7268]">بەشی هەڵبژێردراو:</span>
            <select
              value={currentDeptId || ''}
              onChange={(e) => onSelectDept(Number(e.target.value))}
              className="flex-1 max-w-sm py-1.5 px-3 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs font-bold text-[#1f2420] outline-none focus:border-[#dbd80f]"
            >
              {departments.map(d => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={onOpenManageDepts}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-[#fafaf8] hover:bg-[#e4e6df] text-xs font-bold rounded-xl text-[#1f2420] transition border border-[#e4e6df]"
          >
            <span>بەڕێوەبردنی بەشەکان</span>
          </button>
        </div>
      )}

      {/* Calendar Card */}
      <div className="bg-white rounded-2xl p-4 border border-[#e4e6df] shadow-xs">
        {/* Month / Year header controls */}
        <div className="flex items-center justify-between pb-3.5 border-b border-[#e4e6df] gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#fbfbe8] border border-[#e2df1b] text-amber-900 flex items-center justify-center font-bold">
              <CalendarIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-[#1f2420]">
                ساڵنامەی ئامادەبوون - {currentDept?.name || 'بەش'}
              </h3>
              <p className="text-xs text-[#6b7268]">
                کلیک لەسەر هەر ڕۆژێک بکە بۆ تۆمارکردن یان دەستکاریکردنی ئامادەبووان
              </p>
            </div>
          </div>

          {/* Month / Year Navigator */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => changeMonth(-1)}
              className="w-8 h-8 rounded-lg border border-[#e4e6df] hover:bg-gray-50 flex items-center justify-center text-gray-700 transition"
              title="مانگی پێشوو"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value))}
              className="py-1.5 px-2.5 bg-[#fafaf8] border border-[#e4e6df] rounded-lg text-xs font-bold text-[#1f2420] outline-none"
            >
              {KURDISH_MONTHS_SHORT.map((m, idx) => (
                <option key={idx} value={idx + 1}>
                  {m}
                </option>
              ))}
            </select>

            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="py-1.5 px-2 bg-[#fafaf8] border border-[#e4e6df] rounded-lg text-xs font-bold text-[#1f2420] outline-none"
            >
              {[selectedYear - 2, selectedYear - 1, selectedYear, selectedYear + 1, selectedYear + 2].map(y => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => changeMonth(1)}
              className="w-8 h-8 rounded-lg border border-[#e4e6df] hover:bg-gray-50 flex items-center justify-center text-gray-700 transition"
              title="مانگی داهاتوو"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Days Grid */}
        <div className="mt-4 bg-[#f8f9f6] rounded-2xl p-3 border border-[#e8eae3]">
          {/* Weekday labels */}
          <div className="grid grid-cols-7 gap-1.5 mb-2 text-center">
            {WEEKDAYS_KURDISH.map((d, i) => (
              <div
                key={i}
                className={`text-[11px] font-black py-1 rounded-md ${
                  d.isWeekend ? 'text-emerald-800 bg-emerald-100/50' : 'text-[#6b7268]'
                }`}
              >
                <span>{d.name}</span>
              </div>
            ))}
          </div>

          {/* Day Cells */}
          <div className="grid grid-cols-7 gap-1.5">
            {/* Empty padding days */}
            {Array.from({ length: firstDayOfWeek }).map((_, i) => (
              <div key={`empty-${i}`} className="aspect-square rounded-xl bg-transparent" />
            ))}

            {/* Actual month days */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const dayStat = dayStatsMap.get(day);
              const hasData = dayStat && (dayStat.present > 0 || dayStat.absent > 0);
              const dow = (firstDayOfWeek + i) % 7;
              const isWeekend = dow === 5 || dow === 6; // Fri or Sat

              return (
                <button
                  type="button"
                  key={day}
                  onClick={() => onOpenDayModal(selectedYear, selectedMonth, day)}
                  className={`aspect-square rounded-xl p-1 sm:p-1.5 flex flex-col items-center justify-between border transition relative group cursor-pointer ${
                    hasData
                      ? 'border-[#dbd80f] bg-white shadow-xs hover:border-[#1f2420]'
                      : isWeekend
                      ? 'bg-[#dbe9dc]/50 border-[#c2dac3] hover:bg-white'
                      : 'bg-white border-[#e4e6df] hover:border-gray-400'
                  }`}
                >
                  <span className="font-extrabold text-xs sm:text-sm text-[#1f2420]">
                    {day}
                  </span>

                  {hasData ? (
                    <div className="w-full flex items-center justify-center gap-1 text-[9px] sm:text-[10px] font-black">
                      {dayStat.present > 0 && (
                        <span className="text-emerald-700 bg-emerald-50 px-1 rounded">
                          ✓{dayStat.present}
                        </span>
                      )}
                      {dayStat.absent > 0 && (
                        <span className="text-red-700 bg-red-50 px-1 rounded">
                          ✗{dayStat.absent}
                        </span>
                      )}
                    </div>
                  ) : (
                    <span className="text-[9px] text-gray-300 group-hover:text-gray-400 font-mono">
                      -
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-between mt-3 text-xs text-[#6b7268] pt-2 border-t border-[#e4e6df] flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
              <span>ئامادەبوو (Present)</span>
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
              <span>ئامادەنەبوو (Absent)</span>
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded bg-[#dbe9dc] border border-[#c2dac3]"></span>
              <span>پشووی هەفتە</span>
            </span>
          </div>

          <span className="text-[11px]">
            کۆی کارمەندانی بەش: <b>{deptEmployees.length}</b>
          </span>
        </div>
      </div>

      {/* Shifts Card */}
      <div className="bg-white rounded-2xl p-4 border border-[#e4e6df] shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#6b7268]" />
            <h4 className="text-sm font-bold text-[#1f2420]">شەفتەکانی ئەم بەشە</h4>
          </div>
          <span className="text-xs text-[#6b7268]">{deptShifts.length} شەفت</span>
        </div>

        {deptShifts.length === 0 ? (
          <div className="text-xs text-[#6b7268] py-2">هیچ شەفتێک بۆ ئەم بەشە دیاری نەکراوە.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {deptShifts.map(s => (
              <div
                key={s.id}
                className="p-2.5 bg-[#fafaf8] border border-[#e4e6df] rounded-xl flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-[#1f2420]">{s.name}</div>
                  <div className="text-[11px] text-[#6b7268] font-mono mt-0.5">ئایدی: {s.code}</div>
                </div>
                <div className="font-mono bg-white px-2 py-0.5 rounded border border-[#e4e6df] text-[11px] font-semibold text-gray-700">
                  {s.hours || 'دیاری نەکراوە'}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Employees list in this department */}
      <div className="bg-white rounded-2xl p-4 border border-[#e4e6df] shadow-xs">
        <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-[#6b7268]" />
            <h4 className="text-sm font-bold text-[#1f2420]">
              کارمەندانی ئەم بەشە ({filteredDeptEmployees.length})
            </h4>
          </div>

          <button
            type="button"
            onClick={onOpenAddEmployee}
            className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#dbd80f] hover:bg-[#c2be0d] text-[#2c2c00] rounded-xl text-xs font-bold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>زیادکردنی کارمەند</span>
          </button>
        </div>

        {/* Search inside employee list */}
        <div className="relative mb-3">
          <Search className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={empSearch}
            onChange={(e) => setEmpSearch(e.target.value)}
            placeholder="گەڕان لە کارمەندانی ئەم بەشە بەپێی ناو یان ئایدی..."
            className="w-full pr-8 pl-3 py-1.5 bg-[#fafaf8] border border-[#e4e6df] rounded-lg text-xs outline-none focus:border-[#dbd80f]"
          />
        </div>

        {filteredDeptEmployees.length === 0 ? (
          <div className="text-xs text-center py-6 text-[#6b7268]">
            هیچ کارمەندێک نەدۆزرایەوە
          </div>
        ) : (
          <div className="divide-y divide-[#f0f1ed]">
            {filteredDeptEmployees.map(e => (
              <div
                key={e.id}
                className="py-2.5 flex items-center justify-between gap-2 hover:bg-gray-50 px-2 rounded-lg transition"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#eceee6] text-[#1f2420] flex items-center justify-center font-bold text-xs">
                    {e.name.slice(0, 1)}
                  </div>
                  <div>
                    <div className="font-bold text-xs text-[#1f2420]">{e.name}</div>
                    <div className="text-[11px] text-[#6b7268] flex items-center gap-2">
                      <span className="font-mono">ئایدی: {e.empCode || '-'}</span>
                      <span>•</span>
                      <span>شەفت: {e.shiftType}</span>
                      {e.hours && <span>({e.hours})</span>}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onOpenEditEmployee(e.id)}
                  className="px-2.5 py-1 text-xs border border-[#e4e6df] rounded-lg text-[#1f2420] hover:bg-white transition"
                >
                  دەستکاری
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
