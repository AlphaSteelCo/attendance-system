import React, { useState } from 'react';
import { Department, Employee } from '../types';
import { X, FileCode, Sparkles, AlertTriangle } from 'lucide-react';

interface BulkAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  departments: Department[];
  currentDeptId: number | null;
  onBulkAdd: (newEmployees: Partial<Employee>[]) => void;
}

export const BulkAddModal: React.FC<BulkAddModalProps> = ({
  isOpen,
  onClose,
  departments,
  currentDeptId,
  onBulkAdd,
}) => {
  const [selectedDeptId, setSelectedDeptId] = useState<number>(currentDeptId || 1);
  const [jsonText, setJsonText] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleFillExample = () => {
    const example = [
      {
        name: 'ئاکۆ عەزیز نەجم',
        code: '1011',
        shift: 'ڕۆژ',
        hours: '08:00 - 16:00',
        phone: '07501112233'
      },
      {
        name: 'شەیما نەوزاد ئەحمەد',
        code: '1012',
        shift: 'ڕۆژ',
        hours: '08:00 - 16:00',
        phone: '07502223344'
      },
      {
        name: 'بەرزان کامیل محەمەد',
        code: '1013',
        shift: 'شەو',
        hours: '18:00 - 08:00',
        phone: '07703334455'
      }
    ];
    setJsonText(JSON.stringify(example, null, 2));
    setErrorMsg('');
  };

  const handleProcess = () => {
    setErrorMsg('');
    const raw = jsonText.trim();
    if (!raw) {
      setErrorMsg('تکایە داتای JSON بنووسە یان نموونە پڕبکەرەوە.');
      return;
    }

    try {
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) {
        setErrorMsg('پێویستە داتاکە بە شێوەی ڕیزبەندی بێت [ { ... }, { ... } ].');
        return;
      }

      const list: Partial<Employee>[] = [];
      parsed.forEach((item: any, idx: number) => {
        if (!item || typeof item !== 'object') return;
        const name = (item.name || item['ناو'] || '').toString().trim();
        if (!name) return;

        const empCode = (item.code || item.empCode || item.id || item['ئایدی'] || item['کۆد'] || `E-${idx + 1}`).toString().trim();
        let shiftType = (item.shift || item.shiftType || item['شەفت'] || 'ڕۆژ').toString().trim();
        if (shiftType !== 'ڕۆژ' && shiftType !== 'شەو') shiftType = 'ڕۆژ';
        const hours = (item.hours || item['کات'] || '08:00 - 16:00').toString().trim();
        const phone = (item.phone || item['مۆبایل'] || '').toString().trim();

        list.push({
          deptId: selectedDeptId,
          name,
          empCode,
          shiftType,
          hours,
          phone,
        });
      });

      if (list.length === 0) {
        setErrorMsg('هیچ کارمەندێکی دروست نەدۆزرایەوە لەناو JSON-ەکەدا. دڵنیابە لە هەبوونی خانەی "name".');
        return;
      }

      onBulkAdd(list);
      onClose();
    } catch (err: any) {
      setErrorMsg(`هەڵە لە فۆرماتی JSON: ${err?.message || 'نەناسراو'}`);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-xs">
      <div className="bg-white w-full max-w-lg max-h-[90vh] rounded-t-3xl sm:rounded-2xl p-5 overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3.5 border-b border-[#e4e6df]">
          <div className="flex items-center gap-2">
            <FileCode className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-extrabold text-[#1f2420]">
              زیادکردنی کۆمەڵە کارمەند بە JSON
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="py-3 overflow-y-auto flex-1 space-y-3">
          <div>
            <label className="block text-xs font-bold text-[#6b7268] mb-1">
              بەشی مەبەست بۆ هاوردەکردنی کارمەندان:
            </label>
            <select
              value={selectedDeptId}
              onChange={(e) => setSelectedDeptId(Number(e.target.value))}
              className="w-full py-2 px-3 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs font-bold text-[#1f2420] outline-none"
            >
              {departments.map(d => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-[#6b7268]">
              دەقی JSON (Array of Objects):
            </label>
            <button
              type="button"
              onClick={handleFillExample}
              className="inline-flex items-center gap-1 text-xs text-amber-900 font-bold hover:underline"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>پڕکردنەوە بە نموونە</span>
            </button>
          </div>

          <textarea
            value={jsonText}
            onChange={(e) => setJsonText(e.target.value)}
            dir="ltr"
            placeholder={`[\n  {\n    "name": "ناوی کارمەند",\n    "code": "1001",\n    "shift": "ڕۆژ",\n    "hours": "08:00 - 16:00"\n  }\n]`}
            className="w-full h-48 p-3 bg-[#1e231f] text-emerald-400 font-mono text-xs rounded-xl outline-none focus:ring-2 focus:ring-[#dbd80f] leading-relaxed"
          />

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        <div className="pt-3 border-t border-[#e4e6df] flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-xs font-bold text-gray-700 rounded-xl transition"
          >
            پاشگەزبوونەوە
          </button>
          <button
            type="button"
            onClick={handleProcess}
            className="px-6 py-2 bg-[#dbd80f] hover:bg-[#c2be0d] text-xs font-black text-[#2c2c00] rounded-xl transition shadow-xs"
          >
            💾 زیادکردنی هەمووان
          </button>
        </div>
      </div>
    </div>
  );
};
