import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Building2, 
  Calendar, 
  UserX, 
  ChevronLeft, 
  X, 
  ArrowUpDown, 
  Filter, 
  Clock, 
  CalendarDays, 
  FileSpreadsheet, 
  Printer, 
  AlertCircle,
  Hash,
  Sun,
  Moon,
  Sparkles,
  CalendarCheck2
} from 'lucide-react';
import { Department, Employee, EmployeeAttendance, AbsentEmployeeRecord, AbsenceDateDetail } from '../types';
import { getAbsentEmployees } from '../lib/storage';
import { KURDISH_MONTHS_SHORT } from '../lib/constants';

interface AdminAbsenceTabProps {
  employees: Employee[];
  departments: Department[];
  attendanceList: EmployeeAttendance[];
  onOpenDayModal?: (year: number, month: number, day: number) => void;
  onUpdateAttendance?: (updatedList: EmployeeAttendance[]) => void;
}

export const AdminAbsenceTab: React.FC<AdminAbsenceTabProps> = ({
  employees,
  departments,
  attendanceList,
  onOpenDayModal,
  onUpdateAttendance,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDeptId, setSelectedDeptId] = useState<number | 'all'>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<'all' | 'current_month' | 'custom'>('all');
  const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
  const [filterMonth, setFilterMonth] = useState<number>(new Date().getMonth() + 1);
  const [sortBy, setSortBy] = useState<'most_absences' | 'least_absences' | 'code' | 'name' | 'dept'>('most_absences');

  // Selected employee to view all absent days modal
  const [activeEmployeeRecord, setActiveEmployeeRecord] = useState<AbsentEmployeeRecord | null>(null);

  // Compute absent records
  const queryOptions = useMemo(() => {
    return {
      deptId: selectedDeptId,
      searchTerm,
      sortBy,
      year: selectedPeriod === 'current_month' ? new Date().getFullYear() : (selectedPeriod === 'custom' ? filterYear : ('all' as const)),
      month: selectedPeriod === 'current_month' ? (new Date().getMonth() + 1) : (selectedPeriod === 'custom' ? filterMonth : ('all' as const)),
    };
  }, [selectedDeptId, searchTerm, sortBy, selectedPeriod, filterYear, filterMonth]);

  const absentRecords = useMemo(() => {
    return getAbsentEmployees(employees, departments, attendanceList, queryOptions);
  }, [employees, departments, attendanceList, queryOptions]);

  // Overall Statistics for absence
  const stats = useMemo(() => {
    const totalAbsentEmps = absentRecords.length;
    const totalAbsentDays = absentRecords.reduce((acc, curr) => acc + curr.totalAbsences, 0);
    const avgAbsence = totalAbsentEmps > 0 ? (totalAbsentDays / totalAbsentEmps).toFixed(1) : '0';

    // Find dept with most absences
    const deptAbsenceMap = new Map<string, number>();
    absentRecords.forEach(r => {
      const current = deptAbsenceMap.get(r.deptName) || 0;
      deptAbsenceMap.set(r.deptName, current + r.totalAbsences);
    });

    let topDept = 'دیاری نەکراوە';
    let topDeptCount = 0;
    deptAbsenceMap.forEach((count, dName) => {
      if (count > topDeptCount) {
        topDeptCount = count;
        topDept = dName;
      }
    });

    return { totalAbsentEmps, totalAbsentDays, avgAbsence, topDept, topDeptCount };
  }, [absentRecords]);

  // Handle remove single absence date if admin wants to fix an accidental mark
  const handleRemoveAbsenceDate = (empId: number, year: number, month: number, day: number) => {
    if (!confirm(`دڵنیایت لە سڕینەوەی نەهاتووی ڕۆژی ${year}/${month}/${day} بۆ ئەم کارمەندە؟`)) return;
    const nextList = attendanceList.filter(
      a => !(a.employeeId === empId && a.year === year && a.month === month && a.day === day)
    );
    if (onUpdateAttendance) {
      onUpdateAttendance(nextList);
    }
    // Update active modal record
    if (activeEmployeeRecord && activeEmployeeRecord.employee.id === empId) {
      const remainingDates = activeEmployeeRecord.absenceDates.filter(
        d => !(d.year === year && d.month === month && d.day === day)
      );
      if (remainingDates.length === 0) {
        setActiveEmployeeRecord(null);
      } else {
        setActiveEmployeeRecord({
          ...activeEmployeeRecord,
          totalAbsences: remainingDates.length,
          periodAbsences: remainingDates.length,
          absenceDates: remainingDates,
        });
      }
    }
  };

  // Export to CSV/Text
  const handleExportCSV = () => {
    if (absentRecords.length === 0) return;
    let csvContent = 'data:text/csv;charset=utf-8,\uFEFF';
    csvContent += 'ناوی کارمەند,کۆد / ئایدی,بەش,شەفت,کاتی دەوام,کۆی ڕۆژەکانی نەهاتن,ڕۆژەکانی نەهاتن\n';

    absentRecords.forEach(r => {
      const datesStr = r.absenceDates.map(d => `${d.formattedDate} (${d.weekday})`).join(' | ');
      csvContent += `"${r.employee.name}","${r.employee.empCode}","${r.deptName}","${r.employee.shiftType}","${r.employee.hours}",${r.totalAbsences},"${datesStr}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `absence_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Print report
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4">
      {/* Top Banner / Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-[#e4e6df] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-[#6b7268]">
            <span>کارمەندانی نەهاتوو</span>
            <div className="p-1.5 rounded-lg bg-red-50 text-red-600">
              <UserX className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-black text-[#1f2420]">{stats.totalAbsentEmps}</span>
            <span className="text-xs text-[#6b7268]">کارمەند</span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#e4e6df] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-[#6b7268]">
            <span>کۆی ڕۆژەکانی نەهاتن</span>
            <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
              <CalendarDays className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-black text-red-600">{stats.totalAbsentDays}</span>
            <span className="text-xs text-[#6b7268]">ڕۆژ</span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#e4e6df] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-[#6b7268]">
            <span>تێکڕای نەهاتن</span>
            <div className="p-1.5 rounded-lg bg-blue-50 text-blue-600">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-black text-[#1f2420]">{stats.avgAbsence}</span>
            <span className="text-xs text-[#6b7268]">ڕۆژ / کارمەند</span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#e4e6df] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-[#6b7268]">
            <span>زۆرترین نەهاتن بەپێی بەش</span>
            <div className="p-1.5 rounded-lg bg-purple-50 text-purple-600">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-1">
            <div className="text-xs font-bold text-[#1f2420] truncate" title={stats.topDept}>
              {stats.topDept}
            </div>
            <div className="text-[11px] text-red-600 font-semibold mt-0.5">
              {stats.topDeptCount > 0 ? `${stats.topDeptCount} ڕۆژ نەهاتن` : 'هیچ نییە'}
            </div>
          </div>
        </div>
      </div>

      {/* Main Filter & Search Card */}
      <div className="bg-white rounded-2xl p-4 border border-[#e4e6df] shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-100/80 text-red-700 flex items-center justify-center font-bold">
              <UserX className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-[#1f2420]">
                لیستی کارمەندانی نەهاتوو (Only Absence Employees)
              </h2>
              <p className="text-xs text-[#6b7268]">
                فلتەرکردن و گەڕان بەپێی ناو، کۆد، بەش لەگەڵ پیشاندانی هەموو ڕۆژەکانی نەهاتن
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={handleExportCSV}
              disabled={absentRecords.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#e4e6df] bg-[#fafaf8] hover:bg-white text-xs font-semibold text-[#1f2420] transition disabled:opacity-40"
              title="داگرتن بە فایلی Excel / CSV"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>داگرتن (Excel)</span>
            </button>
            <button
              type="button"
              onClick={handlePrint}
              disabled={absentRecords.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#e4e6df] bg-[#fafaf8] hover:bg-white text-xs font-semibold text-[#1f2420] transition disabled:opacity-40"
              title="چاپکردنی ڕاپۆرت"
            >
              <Printer className="w-3.5 h-3.5 text-[#6b7268]" />
              <span>چاپ</span>
            </button>
          </div>
        </div>

        {/* Search Bar - Big and Focused */}
        <div className="relative">
          <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-[#6b7268]">
            <Search className="w-4 h-4 text-gray-400" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="🔍 گەڕان بە ناو یان ئایدی/کۆدی کارمەند یان ناوی بەش (ناوی کارمەند یان کۆد بنووسە)..."
            className="w-full pl-9 pr-10 py-2.5 bg-[#fafaf8] focus:bg-white border border-[#e4e6df] focus:border-[#dbd80f] rounded-xl text-sm outline-none transition placeholder:text-gray-400"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 hover:text-gray-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Controls row: Department, Period, Sort */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          {/* Department filter */}
          <div>
            <label className="block text-[11px] font-bold text-[#6b7268] mb-1">
              شوێنی بەش (Department):
            </label>
            <div className="relative">
              <select
                value={selectedDeptId}
                onChange={(e) => setSelectedDeptId(e.target.value === 'all' ? 'all' : Number(e.target.value))}
                className="w-full py-2 px-3 bg-white border border-[#e4e6df] rounded-lg text-xs font-medium text-[#1f2420] outline-none focus:border-[#dbd80f]"
              >
                <option value="all">🏢 هەموو بەشەکان ({departments.length} بەش)</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>
                    🏢 {d.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Time Period Filter */}
          <div>
            <label className="block text-[11px] font-bold text-[#6b7268] mb-1">
              ماوەی کاتی (Time Period):
            </label>
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value as any)}
              className="w-full py-2 px-3 bg-white border border-[#e4e6df] rounded-lg text-xs font-medium text-[#1f2420] outline-none focus:border-[#dbd80f]"
            >
              <option value="all">📅 هەموو کاتەکان (مێژووی تەواو)</option>
              <option value="current_month">🗓️ ئەم مانگە ({KURDISH_MONTHS_SHORT[new Date().getMonth()]})</option>
              <option value="custom">🎯 مانگ و ساڵی دیاریکراو</option>
            </select>
          </div>

          {/* Sorting */}
          <div>
            <label className="block text-[11px] font-bold text-[#6b7268] mb-1">
              ڕیزبەندی بەپێی (Sort By):
            </label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full py-2 px-3 bg-white border border-[#e4e6df] rounded-lg text-xs font-medium text-[#1f2420] outline-none focus:border-[#dbd80f]"
            >
              <option value="most_absences">🔥 زۆرترین نەهاتوو بەرەو کەمترین</option>
              <option value="least_absences">📉 کەمترین نەهاتوو بەرەو زۆرترین</option>
              <option value="code">🔢 ئایدی / کۆدی کارمەند</option>
              <option value="name">👤 ناوی کارمەند (ئەلفوبێ)</option>
              <option value="dept">🏢 ناوی بەش</option>
            </select>
          </div>
        </div>

        {/* Custom Month/Year picker if custom selected */}
        {selectedPeriod === 'custom' && (
          <div className="flex items-center gap-2 p-2.5 bg-amber-50/70 border border-amber-200/60 rounded-xl text-xs">
            <span className="font-bold text-amber-900">هەڵبژاردنی مانگ:</span>
            <select
              value={filterMonth}
              onChange={(e) => setFilterMonth(Number(e.target.value))}
              className="bg-white border border-amber-300 rounded-md py-1 px-2 text-xs font-medium"
            >
              {KURDISH_MONTHS_SHORT.map((m, idx) => (
                <option key={idx} value={idx + 1}>
                  {m}
                </option>
              ))}
            </select>
            <span className="font-bold text-amber-900 mr-2">ساڵ:</span>
            <select
              value={filterYear}
              onChange={(e) => setFilterYear(Number(e.target.value))}
              className="bg-white border border-amber-300 rounded-md py-1 px-2 text-xs font-medium"
            >
              {[filterYear - 2, filterYear - 1, filterYear, filterYear + 1].map(y => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Results List Card */}
      <div className="bg-white rounded-2xl p-4 border border-[#e4e6df] shadow-xs">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#e4e6df]">
          <div className="flex items-center gap-2 text-xs text-[#6b7268]">
            <span>ئەنجامەکان:</span>
            <span className="inline-flex items-center justify-center px-2 py-0.5 rounded-full bg-red-100 text-red-800 font-bold text-xs">
              {absentRecords.length} کارمەندی نەهاتوو
            </span>
          </div>
          <span className="text-[11px] text-[#6b7268]">
            کلیک لەسەر هەر کارمەندێک بکە بۆ بینینی هەموو ڕۆژەکانی نەهاتن
          </span>
        </div>

        {absentRecords.length === 0 ? (
          <div className="py-12 px-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-3">
              <CalendarCheck2 className="w-7 h-7" />
            </div>
            <h3 className="text-sm font-bold text-[#1f2420]">هیچ کارمەندێکی نەهاتوو نەدۆزرایەوە!</h3>
            <p className="text-xs text-[#6b7268] max-w-sm mx-auto mt-1">
              {searchTerm || selectedDeptId !== 'all' || selectedPeriod !== 'all'
                ? 'بەپێی ئەم فلتەرانەی دیاریت کردووە هیچ کارمەندێکی نەهاتوو بوونی نییە.'
                : 'لە تەواوی سیستەمدا هیچ تۆمارێکی نەهاتووی کارمەندان نەدۆزرایەوە.'}
            </p>
            {(searchTerm || selectedDeptId !== 'all' || selectedPeriod !== 'all') && (
              <button
                type="button"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedDeptId('all');
                  setSelectedPeriod('all');
                }}
                className="mt-3.5 px-3 py-1.5 bg-[#f4f5f2] hover:bg-[#e4e6df] text-xs font-semibold rounded-lg text-[#1f2420] transition"
              >
                پاککردنەوەی فلتەرەکان
              </button>
            )}
          </div>
        ) : (
          <div className="divide-y divide-[#f0f1ed]">
            {absentRecords.map((record) => {
              const isNight = record.employee.shiftType === 'شەو';
              return (
                <div
                  key={record.employee.id}
                  onClick={() => setActiveEmployeeRecord(record)}
                  className="py-3 px-2 sm:px-3 hover:bg-[#f9faf7] rounded-xl transition cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                >
                  {/* Left info: Name, ID, Dept */}
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#eceee6] text-[#1f2420] flex items-center justify-center font-bold text-sm shrink-0 group-hover:bg-[#dbd80f] transition">
                      {record.employee.name.slice(0, 1)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-sm text-[#1f2420] group-hover:text-amber-900 transition">
                          {record.employee.name}
                        </span>
                        <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-gray-100 text-gray-700 text-[11px] font-mono font-semibold">
                          <Hash className="w-3 h-3 opacity-60" />
                          {record.employee.empCode || 'بێ ئایدی'}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 mt-1 text-xs text-[#6b7268] flex-wrap">
                        {/* Place of department */}
                        <span className="inline-flex items-center gap-1 font-medium text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md">
                          <Building2 className="w-3 h-3 text-emerald-600" />
                          <span>{record.deptName}</span>
                        </span>

                        {/* Shift & Hours */}
                        <span className="inline-flex items-center gap-1">
                          {isNight ? <Moon className="w-3 h-3 text-indigo-500" /> : <Sun className="w-3 h-3 text-amber-500" />}
                          <span>شەفتی {record.employee.shiftType}</span>
                          {record.employee.hours && (
                            <span className="text-[11px] opacity-80">({record.employee.hours})</span>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right side: Total absence badge & click indicator */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 self-stretch sm:self-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-gray-100">
                    <div className="text-right">
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-50 border border-red-200 text-red-700 font-extrabold text-xs">
                        <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                        <span>{record.totalAbsences} ڕۆژ نەهاتوو</span>
                      </div>
                      <div className="text-[10px] text-[#6b7268] mt-0.5">
                        دوایین نەهاتن: {record.absenceDates[0]?.formattedDate || '-'}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-xs font-bold text-amber-800 bg-[#fbfbe8] group-hover:bg-[#dbd80f] px-3 py-1.5 rounded-lg transition shrink-0">
                      <span>بینینی ڕۆژەکان</span>
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* =========================================================================
          MODAL: SHOW ALL DAYS OF ABSENCE FOR CLICKED EMPLOYEE
          "when I click on it show all days"
         ========================================================================= */}
      {activeEmployeeRecord && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-xs">
          <div className="bg-white w-full max-w-xl max-h-[90vh] rounded-t-3xl sm:rounded-2xl p-5 overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex items-start justify-between pb-3.5 border-b border-[#e4e6df]">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center font-black text-base">
                  <UserX className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-[#1f2420]">
                    {activeEmployeeRecord.employee.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-0.5 text-xs text-[#6b7268] flex-wrap">
                    <span className="font-mono bg-gray-100 px-1.5 py-0.5 rounded font-bold">
                      کۆد: {activeEmployeeRecord.employee.empCode}
                    </span>
                    <span>•</span>
                    <span className="text-emerald-800 font-semibold">
                      {activeEmployeeRecord.deptName}
                    </span>
                    <span>•</span>
                    <span>
                      {activeEmployeeRecord.employee.shiftType} ({activeEmployeeRecord.employee.hours})
                    </span>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveEmployeeRecord(null)}
                className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Sub-header badge */}
            <div className="py-2.5 px-3 bg-red-50/70 border border-red-200/60 rounded-xl my-3 flex items-center justify-between text-xs">
              <span className="font-bold text-red-900">
                کۆی گشتی ڕۆژەکانی ئامادەنەبوون:
              </span>
              <span className="font-black text-sm text-red-700 bg-red-100 px-2.5 py-0.5 rounded-full">
                {activeEmployeeRecord.absenceDates.length} ڕۆژ
              </span>
            </div>

            {/* List of All Absent Days */}
            <div className="overflow-y-auto flex-1 space-y-2 pr-1 pl-1">
              <div className="text-xs font-extrabold text-[#6b7268] mb-1">
                خشتەی وردەکاری تەواوی ڕۆژەکان:
              </div>

              {activeEmployeeRecord.absenceDates.map((d, index) => (
                <div
                  key={`${d.year}-${d.month}-${d.day}`}
                  className="p-3 bg-[#fafaf8] border border-[#e4e6df] rounded-xl flex items-center justify-between gap-2 hover:border-red-300 transition"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-red-100/90 text-red-800 flex items-center justify-center font-bold text-xs shrink-0">
                      {index + 1}
                    </div>
                    <div>
                      <div className="font-extrabold text-sm text-[#1f2420] flex items-center gap-2">
                        <span>{d.weekday}</span>
                        <span className="font-mono text-xs bg-white px-2 py-0.5 rounded border border-gray-200 text-gray-800">
                          {d.formattedDate}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#6b7268] mt-0.5 flex items-center gap-2">
                        <span>مانگی {d.monthName}</span>
                        {d.note && (
                          <span className="text-amber-700 bg-amber-50 px-1.5 py-0.2 rounded">
                            هۆکار: {d.note}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {onOpenDayModal && (
                      <button
                        type="button"
                        onClick={() => {
                          setActiveEmployeeRecord(null);
                          onOpenDayModal(d.year, d.month, d.day);
                        }}
                        className="px-2.5 py-1 bg-white hover:bg-gray-50 border border-gray-200 rounded-lg text-[11px] font-semibold text-gray-700 transition"
                        title="کردنەوەی ڕۆژمێری ئەم ڕۆژە"
                      >
                        ڕۆژمێر
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleRemoveAbsenceDate(activeEmployeeRecord.employee.id, d.year, d.month, d.day)}
                      className="px-2 py-1 text-red-600 hover:bg-red-50 rounded-lg text-[11px] font-medium transition"
                      title="سڕینەوەی ئەم نەهاتووە (گۆڕین بۆ ئاسایی)"
                    >
                      سڕینەوە
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="pt-3.5 mt-2 border-t border-[#e4e6df] flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setActiveEmployeeRecord(null)}
                className="px-5 py-2 bg-[#1f2420] hover:bg-black text-white text-xs font-bold rounded-xl transition"
              >
                داخستن
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
