import React, { useState } from 'react';
import { Department } from '../types';
import { ShieldCheck, Lock, ArrowLeft, Building2, KeyRound, Sparkles } from 'lucide-react';

interface LoginScreenProps {
  onLoginSuccess: (session: { role: 'admin' | 'dept'; deptId?: number; deptName?: string }) => void;
  departments: Department[];
  adminPassword: string;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  departments,
  adminPassword,
}) => {
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [showHelper, setShowHelper] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const trimmed = password.trim();
    if (!trimmed) {
      setErrorMsg('تکایە وشەی نهێنی بنووسە.');
      return;
    }

    // Check admin
    if (trimmed === adminPassword) {
      onLoginSuccess({ role: 'admin' });
      return;
    }

    // Check dept password
    const matchedDept = departments.find(d => d.password === trimmed);
    if (matchedDept) {
      onLoginSuccess({
        role: 'dept',
        deptId: matchedDept.id,
        deptName: matchedDept.name,
      });
      return;
    }

    setErrorMsg('وشەی نهێنی هەڵەیە! تکایە دووبارە تاقی بکەرەوە.');
  };

  const handleQuickLogin = (pass: string) => {
    setPassword(pass);
    setErrorMsg('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#fcfce9] via-[#f4f5f2] to-[#eef0eb] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-xl border border-[#e4e6df] text-center">
        {/* Logo / Badge */}
        <div className="w-16 h-16 rounded-2xl bg-[#dbd80f] flex items-center justify-center text-2xl font-black mx-auto mb-3 shadow-xs">
          📋
        </div>

        <h1 className="text-lg font-black text-[#1f2420]">سیستەمی ئامادەبوونی کارمەندان</h1>
        <p className="text-xs text-[#6b7268] mt-1 mb-6">
          وشەی نهێنی ئەدمین یان بەش بنووسە بۆ چوونەژوورەوە
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="text-right">
            <label className="block text-xs font-bold text-[#6b7268] mb-1.5">
              وشەی نهێنی (Password)
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••"
                autoFocus
                className="w-full pr-10 pl-3 py-3 bg-[#fafaf8] focus:bg-white border border-[#e4e6df] focus:border-[#dbd80f] rounded-2xl text-sm font-mono outline-none transition"
              />
            </div>
          </div>

          {errorMsg && (
            <div className="text-xs text-red-600 font-bold bg-red-50 py-2 px-3 rounded-xl border border-red-200 animate-shake">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3 bg-[#dbd80f] hover:bg-[#c2be0d] active:scale-98 text-[#2c2c00] font-black text-sm rounded-2xl transition shadow-xs flex items-center justify-center gap-2"
          >
            <span>چوونەژوورەوە</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </form>

        {/* Quick Helper for Demo / Testing */}
        <div className="mt-6 pt-4 border-t border-[#f0f1ed]">
          <button
            type="button"
            onClick={() => setShowHelper(!showHelper)}
            className="text-[11px] text-[#6b7268] hover:text-gray-900 font-bold flex items-center justify-center gap-1 mx-auto"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>وشە نهێنییە پێشوەختەکان (Demo Credentials)</span>
          </button>

          {showHelper && (
            <div className="mt-3 p-3 bg-[#f8f9f6] border border-[#e4e6df] rounded-xl text-right text-xs space-y-2">
              <div className="flex items-center justify-between pb-1 border-b border-gray-200">
                <span className="font-bold text-gray-800">بەڕێوەبەر (Admin):</span>
                <button
                  type="button"
                  onClick={() => handleQuickLogin(adminPassword)}
                  className="px-2 py-0.5 bg-amber-200/60 hover:bg-amber-200 rounded font-mono font-bold text-amber-900"
                >
                  {adminPassword}
                </button>
              </div>

              <div className="text-[11px] font-bold text-gray-500 pt-1">وشەی نهێنی بەشەکان:</div>
              {departments.slice(0, 3).map(d => (
                <div key={d.id} className="flex items-center justify-between text-[11px]">
                  <span className="truncate max-w-[170px] text-gray-700">{d.name}:</span>
                  <button
                    type="button"
                    onClick={() => handleQuickLogin(d.password || '1111')}
                    className="px-1.5 py-0.5 bg-gray-200 hover:bg-gray-300 rounded font-mono text-gray-800 font-semibold"
                  >
                    {d.password}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
