import React, { useState, useEffect, useMemo } from 'react';
import { Department, Employee, EmployeeAttendance, AttendanceStatus } from '../types';
import { KURDISH_MONTHS_SHORT, WEEKDAYS_KURDISH } from '../lib/constants';
import { X, Check, Search, CheckCheck, RotateCcw, UserCheck, UserX } from 'lucide-react';

interface DayModalProps {
  isOpen: boolean;
  onClose: () => void;
  year: number;
  month: number;
  day: number;
  currentDeptId: number | null;
  departments: Department[];
  employees: Employee[];
  attendanceList: EmployeeAttendance[];
  onSave: (updatedAttendances: EmployeeAttendance[]) => void;
}

export const DayModal: React.FC<DayModalProps> = ({
  isOpen,
  onClose,
  year,
  month,
  day,
  currentDeptId,
  departments,
  employees,
  attendanceList,
  onSave,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusMap, setStatusMap] = useState<{ [empId: number]: AttendanceStatus | null }>({});

  const currentDept = departments.find(d => d.id === currentDeptId);
  const deptEmployees = useMemo(() => {
    return employees.filter(e => e.deptId === currentDeptId);
  }, [employees, currentDeptId]);

  // Load existing day attendance on modal open
  useEffect(() => {
    if (!isOpen) return;
    const initialMap: { [empId: number]: AttendanceStatus | null } = {};
    
    deptEmployees.forEach(emp => {
      const rec = attendanceList.find(
        a => a.year === year && a.month === month && a.day === day && a.employeeId === emp.id
      );
      initialMap[emp.id] = rec ? rec.status : null;
    });

    setStatusMap(initialMap);
    setSearchTerm('');
  }, [isOpen, year, month, day, deptEmployees, attendanceList]);

  if (!isOpen) return null;

  const weekdayIndex = new Date(year, month - 1, day).getDay();
  const weekdayName = WEEKDAYS_KURDISH[weekdayIndex]?.name || 'ڕۆژ';
  const monthName = KURDISH_MONTHS_SHORT[month - 1] || `مانگی ${month}`;

  // Filtered employees in modal
  const filteredEmployees = deptEmployees.filter(emp => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return emp.name.toLowerCase().includes(term) || (emp.empCode || '').toLowerCase().includes(term);
  });

  const counts = {
    present: Object.values(statusMap).filter(s => s === 'present').length,
    absent: Object.values(statusMap).filter(s => s === 'absent').length,
    total: deptEmployees.length,
  };

  const handleToggle = (empId: number, status: AttendanceStatus) => {
    setStatusMap(prev => ({
      ...prev,
      [empId]: prev[empId] === status ? null : status,
    }));
  };

  const handleMarkAll = (status: AttendanceStatus | null) => {
    const updated: { [empId: number]: AttendanceStatus | null } = {};
    deptEmployees.forEach(e => {
      updated[e.id] = status;
    });
    setStatusMap(updated);
  };

  const handleSave = () => {
    // Merge new day state with existing attendance list
    let nextList = attendanceList.filter(
      a => !(a.year === year && a.month === month && a.day === day && deptEmployees.some(e => e.id === a.employeeId))
    );

    Object.entries(statusMap).forEach(([empIdStr, status]) => {
      const empId = Number(empIdStr);
      if (status) {
        nextList.push({
          year,
          month,
          day,
          employeeId: empId,
          status,
        });
      }
    });

    onSave(nextList);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-xs">
      <div className="bg-white w-full max-w-lg max-h-[90vh] rounded-t-3xl sm:rounded-2xl p-4 sm:p-5 overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-[#e4e6df]">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-md bg-[#dbd80f] font-black text-xs text-[#2c2c00]">
                ڕۆژی {day}
              </span>
              <h3 className="text-base font-extrabold text-[#1f2420]">
                ئامادەبوونی {weekdayName} • {monthName} {year}
              </h3>
            </div>
            <p className="text-xs text-[#6b7268] mt-1">
              بەشی {currentDept?.name || '-'}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick summary & Bulk buttons */}
        <div className="py-2.5 px-3 bg-[#f8f9f6] rounded-xl my-3 flex items-center justify-between gap-2 text-xs flex-wrap border border-[#e4e6df]">
          <div className="flex items-center gap-3 font-semibold">
            <span className="text-[#6b7268]">کۆی کارمەندان: {counts.total}</span>
            <span className="text-emerald-700 font-bold">✅ ئامادە: {counts.present}</span>
            <span className="text-red-600 font-bold">❌ نەهاتوو: {counts.absent}</span>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => handleMarkAll('present')}
              className="px-2 py-1 bg-white hover:bg-emerald-50 border border-[#e4e6df] rounded text-[11px] font-bold text-emerald-700 transition"
              title="هەمووان ئامادە بکە"
            >
              هەمووان ئامادە
            </button>
            <button
              type="button"
              onClick={() => handleMarkAll(null)}
              className="px-2 py-1 bg-white hover:bg-gray-100 border border-[#e4e6df] rounded text-[11px] font-bold text-gray-600 transition"
              title="سڕینەوەی دیاریکراوەکان"
            >
              پاککردنەوە
            </button>
          </div>
        </div>

        {/* Search inside day */}
        <div className="relative mb-2.5">
          <Search className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="گەڕان لە کارمەندانی ئەم ڕۆژە..."
            className="w-full pr-8 pl-3 py-2 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs outline-none focus:border-[#dbd80f]"
          />
        </div>

        {/* Employees List */}
        <div className="overflow-y-auto flex-1 space-y-2 pr-1 pl-1">
          {filteredEmployees.length === 0 ? (
            <div className="text-center py-8 text-xs text-[#6b7268]">
              هیچ کارمەندێک نەدۆزرایەوە
            </div>
          ) : (
            filteredEmployees.map(emp => {
              const currentStatus = statusMap[emp.id];
              return (
                <div
                  key={emp.id}
                  className={`p-2.5 rounded-xl border transition flex items-center justify-between gap-2 ${
                    currentStatus === 'present'
                      ? 'bg-emerald-50/50 border-emerald-200'
                      : currentStatus === 'absent'
                      ? 'bg-red-50/50 border-red-200'
                      : 'bg-[#fafaf8] border-[#e4e6df]'
                  }`}
                >
                  <div>
                    <div className="font-bold text-xs text-[#1f2420]">{emp.name}</div>
                    <div className="text-[11px] text-[#6b7268] flex items-center gap-2 mt-0.5">
                      <span className="font-mono bg-white px-1.5 py-0.2 rounded border border-gray-200">
                        کۆد: {emp.empCode || '-'}
                      </span>
                      <span>شەفتی {emp.shiftType}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleToggle(emp.id, 'present')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-black transition flex items-center gap-1 ${
                        currentStatus === 'present'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-white border border-[#e4e6df] text-[#6b7268] hover:bg-emerald-50 hover:text-emerald-700'
                      }`}
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>ئامادە</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleToggle(emp.id, 'absent')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-black transition flex items-center gap-1 ${
                        currentStatus === 'absent'
                          ? 'bg-red-600 text-white shadow-xs'
                          : 'bg-white border border-[#e4e6df] text-[#6b7268] hover:bg-red-50 hover:text-red-700'
                      }`}
                    >
                      <UserX className="w-3.5 h-3.5" />
                      <span>نەهاتوو</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer actions */}
        <div className="pt-3.5 mt-2 border-t border-[#e4e6df] flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-[#f4f5f2] hover:bg-[#e4e6df] text-xs font-bold text-[#1f2420] rounded-xl transition"
          >
            پاشگەزبوونەوە
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-6 py-2 bg-[#dbd80f] hover:bg-[#c2be0d] text-xs font-black text-[#2c2c00] rounded-xl transition shadow-xs"
          >
            💾 هەڵگرتنی ئامادەبوون
          </button>
        </div>
      </div>
    </div>
  );
};
