import React, { useState } from 'react';
import { X, Key, RotateCcw, Download, Upload, Shield, CheckCircle, Database } from 'lucide-react';
import { Department, Employee, EmployeeAttendance, Shift } from '../types';
import { STORAGE_KEYS } from '../lib/constants';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAdminPass: string;
  onChangeAdminPass: (newPass: string) => void;
  onResetToSampleData: () => void;
  departments: Department[];
  shifts: Shift[];
  employees: Employee[];
  attendanceList: EmployeeAttendance[];
  onImportAllData: (data: {
    departments: Department[];
    shifts: Shift[];
    employees: Employee[];
    attendance: EmployeeAttendance[];
  }) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currentAdminPass,
  onChangeAdminPass,
  onResetToSampleData,
  departments,
  shifts,
  employees,
  attendanceList,
  onImportAllData,
}) => {
  const [activeTab, setActiveTab] = useState<'admin' | 'backup'>('admin');
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [msg, setMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  if (!isOpen) return null;

  const handleChangePass = (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    if (oldPass !== currentAdminPass) {
      setMsg({ text: 'وشەی نهێنی پێشوو هەڵەیە!', type: 'error' });
      return;
    }
    if (!newPass.trim()) {
      setMsg({ text: 'وشەی نهێنی نوێ بەتاڵە!', type: 'error' });
      return;
    }
    if (newPass !== confirmPass) {
      setMsg({ text: 'وشەی نهێنی نوێ و دووپاتکردنەوەکەی وەک یەک نین!', type: 'error' });
      return;
    }

    onChangeAdminPass(newPass.trim());
    setOldPass('');
    setNewPass('');
    setConfirmPass('');
    setMsg({ text: 'وشەی نهێنی ئەدمین بە سەرکەوتوویی گۆڕدرا ✓', type: 'success' });
  };

  const handleExportBackup = () => {
    const backupObj = {
      app: 'employee-attendance-system',
      version: '2.0',
      exportedAt: new Date().toISOString(),
      departments,
      shifts,
      employees,
      attendance: attendanceList,
    };
    const jsonStr = JSON.stringify(backupObj, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const content = ev.target?.result as string;
        const parsed = JSON.parse(content);
        if (!parsed.departments || !parsed.employees || !parsed.attendance) {
          alert('فایلەکە ساختەی فۆرماتی دروست نییە.');
          return;
        }
        if (confirm('ئایا دڵنیایت دەتەوێت داتاکانی ئەم فایلە جێگیر بکەیت؟')) {
          onImportAllData({
            departments: parsed.departments,
            shifts: parsed.shifts || [],
            employees: parsed.employees,
            attendance: parsed.attendance,
          });
          alert('داتاکان بە سەرکەوتوویی هاوردە کران ✓');
          onClose();
        }
      } catch (err) {
        alert('هەڵە لە خوێندنەوەی فایلی JSON.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-2xl p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-[#e4e6df]">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#2c2c00]" />
            <h3 className="text-base font-extrabold text-[#1f2420]">ڕێکخستنەکانی سیستەم</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex gap-1.5 p-1 bg-gray-100 rounded-xl my-3 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('admin')}
            className={`flex-1 py-1.5 rounded-lg transition ${activeTab === 'admin' ? 'bg-white text-[#1f2420] shadow-xs' : 'text-gray-600'}`}
          >
            وشەی نهێنی
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('backup')}
            className={`flex-1 py-1.5 rounded-lg transition ${activeTab === 'backup' ? 'bg-white text-[#1f2420] shadow-xs' : 'text-gray-600'}`}
          >
            باکئەپ و داتا
          </button>
        </div>

        {activeTab === 'admin' ? (
          <form onSubmit={handleChangePass} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-[#6b7268] mb-1">وشەی نهێنی ئێستا</label>
              <input
                type="password"
                required
                value={oldPass}
                onChange={(e) => setOldPass(e.target.value)}
                placeholder="••••••"
                className="w-full py-2 px-3 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs outline-none focus:border-[#dbd80f]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#6b7268] mb-1">وشەی نهێنی نوێ</label>
              <input
                type="password"
                required
                value={newPass}
                onChange={(e) => setNewPass(e.target.value)}
                placeholder="••••••"
                className="w-full py-2 px-3 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs outline-none focus:border-[#dbd80f]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#6b7268] mb-1">دووپاتکردنەوەی وشەی نهێنی نوێ</label>
              <input
                type="password"
                required
                value={confirmPass}
                onChange={(e) => setConfirmPass(e.target.value)}
                placeholder="••••••"
                className="w-full py-2 px-3 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs outline-none focus:border-[#dbd80f]"
              />
            </div>

            {msg && (
              <div className={`p-2.5 rounded-xl text-xs font-bold ${msg.type === 'success' ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-800'}`}>
                {msg.text}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2 bg-[#dbd80f] hover:bg-[#c2be0d] text-xs font-black text-[#2c2c00] rounded-xl transition mt-2"
            >
              گۆڕینی وشەی نهێنی
            </button>
          </form>
        ) : (
          <div className="space-y-3">
            <div className="p-3 bg-[#f8f9f6] border border-[#e4e6df] rounded-xl space-y-2">
              <div className="text-xs font-bold text-[#1f2420] flex items-center gap-1.5">
                <Download className="w-4 h-4 text-emerald-600" />
                <span>داگرتنی هەموو داتاکان (Backup JSON)</span>
              </div>
              <p className="text-[11px] text-[#6b7268]">
                داگرتنی کۆپییەکی یەدەگ لە تەواوی بەشەکان، کارمەندان و تۆماری ئامادەبوون.
              </p>
              <button
                type="button"
                onClick={handleExportBackup}
                className="w-full py-1.5 bg-white hover:bg-gray-50 border border-gray-200 text-xs font-bold text-gray-800 rounded-lg transition"
              >
                داگرتنی باکئەپ (.json)
              </button>
            </div>

            <div className="p-3 bg-[#f8f9f6] border border-[#e4e6df] rounded-xl space-y-2">
              <div className="text-xs font-bold text-[#1f2420] flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-indigo-600" />
                <span>هاوردەکردنی باکئەپ (Restore)</span>
              </div>
              <label className="block w-full text-center py-1.5 bg-white hover:bg-gray-50 border border-gray-200 text-xs font-bold text-gray-800 rounded-lg cursor-pointer transition">
                <span>دیاریکردنی فایلی باکئەپ</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportBackup}
                  className="hidden"
                />
              </label>
            </div>

            <div className="p-3 bg-red-50/70 border border-red-200 rounded-xl space-y-2">
              <div className="text-xs font-bold text-red-800 flex items-center gap-1.5">
                <RotateCcw className="w-4 h-4 text-red-600" />
                <span>گێڕانەوە بۆ داتای نموونەیی سەرەتا</span>
              </div>
              <p className="text-[11px] text-red-700/80">
                پڕکردنەوەی داتابەیس بە کارمەندان، بەشەکان و نەهاتووی نموونەیی بۆ تاقیکردنەوە.
              </p>
              <button
                type="button"
                onClick={() => {
                  if (confirm('دڵنیایت لە گێڕانەوەی داتاکان بۆ نموونەی سەرەتا؟')) {
                    onResetToSampleData();
                    onClose();
                  }
                }}
                className="w-full py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg transition"
              >
                گێڕانەوە بۆ داتای نموونە
              </button>
            </div>
          </div>
        )}

        <div className="pt-3.5 mt-3 border-t border-[#e4e6df] flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold rounded-xl transition"
          >
            داخستن
          </button>
        </div>
      </div>
    </div>
  );
};
