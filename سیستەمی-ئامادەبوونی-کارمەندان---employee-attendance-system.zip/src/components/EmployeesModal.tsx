import React, { useState, useEffect } from 'react';
import { Department, Employee } from '../types';
import { X, UserPlus, Trash2, Building2, Clock, Phone, Hash } from 'lucide-react';

interface EmployeesModalProps {
  isOpen: boolean;
  onClose: () => void;
  departments: Department[];
  currentDeptId: number | null;
  employeeToEdit: Employee | null;
  onSaveEmployee: (emp: Partial<Employee>) => void;
  onDeleteEmployee: (empId: number, deptPassword?: string) => boolean | void;
  isAdmin: boolean;
}

export const EmployeesModal: React.FC<EmployeesModalProps> = ({
  isOpen,
  onClose,
  departments,
  currentDeptId,
  employeeToEdit,
  onSaveEmployee,
  onDeleteEmployee,
  isAdmin,
}) => {
  const [name, setName] = useState('');
  const [empCode, setEmpCode] = useState('');
  const [deptId, setDeptId] = useState<number>(currentDeptId || 1);
  const [shiftType, setShiftType] = useState('ڕۆژ');
  const [hours, setHours] = useState('08:00 - 16:00');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (employeeToEdit) {
      setName(employeeToEdit.name);
      setEmpCode(employeeToEdit.empCode || '');
      setDeptId(employeeToEdit.deptId);
      setShiftType(employeeToEdit.shiftType || 'ڕۆژ');
      setHours(employeeToEdit.hours || '08:00 - 16:00');
      setPhone(employeeToEdit.phone || '');
    } else {
      setName('');
      setEmpCode('');
      setDeptId(currentDeptId || departments[0]?.id || 1);
      setShiftType('ڕۆژ');
      setHours('08:00 - 16:00');
      setPhone('');
    }
  }, [isOpen, employeeToEdit, currentDeptId, departments]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSaveEmployee({
      ...(employeeToEdit ? { id: employeeToEdit.id } : {}),
      name: name.trim(),
      empCode: empCode.trim() || String(Math.floor(1000 + Math.random() * 9000)),
      deptId,
      shiftType,
      hours: hours.trim() || '08:00 - 16:00',
      phone: phone.trim(),
    });
    onClose();
  };

  const handleDelete = () => {
    if (!employeeToEdit) return;
    const currentEmpDept = departments.find(d => d.id === employeeToEdit.deptId);
    let enteredPass = '';
    if (!isAdmin) {
      enteredPass = prompt('تکایە وشەی نهێنی بەش بنووسە بۆ دڵنیابوونەوە لە سڕینەوە:') || '';
      if (!enteredPass) return;
    } else {
      if (!confirm(`دڵنیایت لە سڕینەوەی کارمەند "${employeeToEdit.name}"؟`)) return;
    }
    const success = onDeleteEmployee(employeeToEdit.id, enteredPass);
    if (success !== false) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-2xl p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-[#e4e6df]">
          <div className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-[#2c2c00]" />
            <h3 className="text-base font-extrabold text-[#1f2420]">
              {employeeToEdit ? 'دەستکاریکردنی کارمەند' : 'زیادکردنی کارمەندی نوێ'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 pt-3">
          <div>
            <label className="block text-xs font-bold text-[#6b7268] mb-1">ناوی کارمەند *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="ناوی چواری کارمەند بنووسە..."
              className="w-full py-2 px-3 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs outline-none focus:border-[#dbd80f]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-[#6b7268] mb-1">کۆد / ئایدی کارمەند</label>
              <div className="relative">
                <Hash className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={empCode}
                  onChange={(e) => setEmpCode(e.target.value)}
                  placeholder="نموونە: 1042"
                  className="w-full pr-8 pl-3 py-2 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs font-mono outline-none focus:border-[#dbd80f]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#6b7268] mb-1">جۆری شەفت</label>
              <select
                value={shiftType}
                onChange={(e) => setShiftType(e.target.value)}
                className="w-full py-2 px-3 bg-white border border-[#e4e6df] rounded-xl text-xs font-bold outline-none focus:border-[#dbd80f]"
              >
                <option value="ڕۆژ">🌞 شەفتی ڕۆژ</option>
                <option value="شەو">🌙 شەفتی شەو</option>
                <option value="تایبەت">⭐ شەفتی تایبەت</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-[#6b7268] mb-1">کاتی کارکردن (Hours)</label>
              <div className="relative">
                <Clock className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={hours}
                  onChange={(e) => setHours(e.target.value)}
                  placeholder="08:00 - 16:00"
                  className="w-full pr-8 pl-3 py-2 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs font-mono outline-none focus:border-[#dbd80f]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#6b7268] mb-1">ژمارەی مۆبایل (ئارەزوومەندانە)</label>
              <div className="relative">
                <Phone className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0750XXXXXXX"
                  className="w-full pr-8 pl-3 py-2 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs font-mono outline-none focus:border-[#dbd80f]"
                />
              </div>
            </div>
          </div>

          {/* Department assignment */}
          <div>
            <label className="block text-xs font-bold text-[#6b7268] mb-1">بەش (Department)</label>
            <div className="relative">
              <Building2 className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
              <select
                value={deptId}
                onChange={(e) => setDeptId(Number(e.target.value))}
                className="w-full pr-8 pl-3 py-2 bg-white border border-[#e4e6df] rounded-xl text-xs font-bold outline-none focus:border-[#dbd80f]"
              >
                {departments.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="pt-3 border-t border-[#e4e6df] flex items-center justify-between gap-2">
            {employeeToEdit ? (
              <button
                type="button"
                onClick={handleDelete}
                className="px-3.5 py-2 text-red-600 hover:bg-red-50 text-xs font-bold rounded-xl transition flex items-center gap-1"
              >
                <Trash2 className="w-4 h-4" />
                <span>سڕینەوە</span>
              </button>
            ) : (
              <div></div>
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-xs font-bold text-gray-700 rounded-xl transition"
              >
                پاشگەزبوونەوە
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-[#dbd80f] hover:bg-[#c2be0d] text-xs font-black text-[#2c2c00] rounded-xl transition shadow-xs"
              >
                {employeeToEdit ? 'هەڵگرتنی گۆڕانکاری' : 'زیادکردن'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
