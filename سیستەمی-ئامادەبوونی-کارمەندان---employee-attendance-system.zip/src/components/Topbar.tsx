import React from 'react';
import { UserSession } from '../types';
import { 
  LogOut, 
  Settings, 
  RefreshCw, 
  Building2, 
  ShieldCheck, 
  UserX, 
  Calendar as CalendarIcon,
  Users
} from 'lucide-react';

interface TopbarProps {
  userSession: UserSession;
  activeAdminTab: 'calendar' | 'absence' | 'alldepts';
  setActiveAdminTab: (tab: 'calendar' | 'absence' | 'alldepts') => void;
  onOpenSettings: () => void;
  onLogout: () => void;
  onManualSync: () => void;
  syncStatus: { text: string; color: string };
  absentCount: number;
}

export const Topbar: React.FC<TopbarProps> = ({
  userSession,
  activeAdminTab,
  setActiveAdminTab,
  onOpenSettings,
  onLogout,
  onManualSync,
  syncStatus,
  absentCount,
}) => {
  const isAdmin = userSession.role === 'admin';

  return (
    <header className="sticky top-0 z-30 bg-[#dbd80f] text-[#2c2c00] shadow-sm border-b border-[#c2be0d]">
      <div className="max-w-6xl mx-auto px-3 sm:px-4 py-2.5">
        <div className="flex items-center justify-between gap-2">
          {/* User profile & Role info */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-black/10 flex items-center justify-center font-bold text-base">
              {isAdmin ? <ShieldCheck className="w-5 h-5" /> : <Building2 className="w-5 h-5" />}
            </div>
            <div>
              <div className="text-sm font-black tracking-tight leading-tight">
                {isAdmin ? 'بەڕێوەبەری سەرەکی (Admin)' : userSession.deptName}
              </div>
              <div className="text-[11px] font-semibold text-[#54530a] flex items-center gap-1.5 mt-0.5">
                <span>{isAdmin ? 'دەسەڵاتی بەڕێوەبردن' : 'سەرپەرشتیاری بەش'}</span>
                <span>•</span>
                <span className="inline-flex items-center gap-1">
                  <span className={`w-2 h-2 rounded-full ${syncStatus.color === 'green' ? 'bg-emerald-600' : 'bg-amber-600 animate-ping'}`}></span>
                  <span className="text-[10px]">{syncStatus.text}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onManualSync}
              className="w-9 h-9 rounded-xl bg-black/10 hover:bg-black/20 text-[#2c2c00] flex items-center justify-center transition"
              title="تازەکردنەوەی زانیارییەکان"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {isAdmin && (
              <button
                type="button"
                onClick={onOpenSettings}
                className="w-9 h-9 rounded-xl bg-black/10 hover:bg-black/20 text-[#2c2c00] flex items-center justify-center transition"
                title="ڕێکخستنەکان"
              >
                <Settings className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={onLogout}
              className="w-9 h-9 rounded-xl bg-black/10 hover:bg-red-600 hover:text-white text-[#2c2c00] flex items-center justify-center transition"
              title="چوونەدەرەوە"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs for Admin & Supervisors */}
        {isAdmin && (
          <nav aria-label="پەڕەی سەرەکیی ئەدمین" className="flex items-center gap-1 mt-2.5 pt-2 border-t border-black/10">
            <button
              type="button"
              onClick={() => setActiveAdminTab('absence')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition relative ${
                activeAdminTab === 'absence'
                  ? 'bg-[#1f2420] text-white shadow-xs'
                  : 'bg-black/5 hover:bg-black/10 text-[#2c2c00]'
              }`}
            >
              <UserX className="w-3.5 h-3.5" />
              <span>کارمەندانی نەهاتوو (Absence Employees)</span>
              {absentCount > 0 && (
                <span className={`px-1.5 py-0.2 text-[10px] font-black rounded-full ${
                  activeAdminTab === 'absence' ? 'bg-red-500 text-white' : 'bg-red-600 text-white'
                }`}>
                  {absentCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveAdminTab('calendar')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
                activeAdminTab === 'calendar'
                  ? 'bg-[#1f2420] text-white shadow-xs'
                  : 'bg-black/5 hover:bg-black/10 text-[#2c2c00]'
              }`}
            >
              <CalendarIcon className="w-3.5 h-3.5" />
              <span>ساڵنامە و ئامادەبوونی بەشەکان</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveAdminTab('alldepts')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
                activeAdminTab === 'alldepts'
                  ? 'bg-[#1f2420] text-white shadow-xs'
                  : 'bg-black/5 hover:bg-black/10 text-[#2c2c00]'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>هەموو بەشەکان ({userSession.deptId ? '١' : 'گشتی'})</span>
            </button>
          </nav>
        )}
      </div>
    </header>
  );
};
