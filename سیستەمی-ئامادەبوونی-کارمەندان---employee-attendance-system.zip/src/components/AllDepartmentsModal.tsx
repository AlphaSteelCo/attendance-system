import React, { useState } from 'react';
import { Department, Employee, Shift } from '../types';
import { Building2, Users, Search, ChevronLeft, Plus, X, Phone, Hash, Clock, FileCode } from 'lucide-react';

interface AllDepartmentsModalProps {
  departments: Department[];
  employees: Employee[];
  shifts: Shift[];
  onSelectDept: (deptId: number) => void;
  onOpenAddEmployeeForDept: (deptId: number) => void;
  onOpenBulkAddForDept: (deptId: number) => void;
  onOpenEditEmployee: (empId: number) => void;
}

export const AllDepartmentsModal: React.FC<AllDepartmentsModalProps> = ({
  departments,
  employees,
  shifts,
  onSelectDept,
  onOpenAddEmployeeForDept,
  onOpenBulkAddForDept,
  onOpenEditEmployee,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedDeptId, setExpandedDeptId] = useState<number | null>(departments[0]?.id || null);

  const filteredDepts = departments.filter(d => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    const matchDept = d.name.toLowerCase().includes(term);
    const hasMatchEmp = employees.some(
      e => e.deptId === d.id && (e.name.toLowerCase().includes(term) || (e.empCode || '').toLowerCase().includes(term))
    );
    return matchDept || hasMatchEmp;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-4 border border-[#e4e6df] shadow-xs space-y-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-[#1f2420]">هەموو بەشەکانی دامەزراوە</h2>
              <p className="text-xs text-[#6b7268]">بینین و گەڕان لە کارمەندانی هەر بەشێک</p>
            </div>
          </div>
          <span className="text-xs font-bold text-gray-700 bg-gray-100 px-3 py-1 rounded-full">
            {departments.length} بەش • {employees.length} کارمەند
          </span>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="گەڕان بە ناوی بەش یان ناوی کارمەند..."
            className="w-full pr-10 pl-3 py-2.5 bg-[#fafaf8] border border-[#e4e6df] rounded-xl text-xs outline-none focus:border-[#dbd80f]"
          />
        </div>
      </div>

      {/* Departments Accordion list */}
      <div className="space-y-3">
        {filteredDepts.map((dept) => {
          const deptEmps = employees.filter(e => e.deptId === dept.id);
          const deptShifts = shifts.filter(s => s.deptId === dept.id);
          const isExpanded = expandedDeptId === dept.id;

          const filteredEmps = deptEmps.filter(e => {
            if (!searchTerm.trim()) return true;
            const term = searchTerm.toLowerCase();
            return e.name.toLowerCase().includes(term) || (e.empCode || '').toLowerCase().includes(term);
          });

          return (
            <div
              key={dept.id}
              className="bg-white rounded-2xl border border-[#e4e6df] shadow-xs overflow-hidden transition"
            >
              {/* Dept bar */}
              <div
                onClick={() => setExpandedDeptId(isExpanded ? null : dept.id)}
                className="p-4 flex items-center justify-between cursor-pointer hover:bg-gray-50/80 transition"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#f8f9f6] border border-[#e4e6df] text-[#1f2420] flex items-center justify-center font-bold">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-[#1f2420]">{dept.name}</h3>
                    <div className="text-[11px] text-[#6b7268] flex items-center gap-2 mt-0.5">
                      <span>{deptEmps.length} کارمەند</span>
                      <span>•</span>
                      <span>{deptShifts.length} شەفت</span>
                      {dept.password && (
                        <>
                          <span>•</span>
                          <span className="font-mono text-gray-500">وشەی نهێنی: {dept.password}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectDept(dept.id);
                    }}
                    className="px-3 py-1 bg-[#fafaf8] hover:bg-[#dbd80f] text-[#1f2420] rounded-lg text-xs font-bold transition border border-[#e4e6df]"
                  >
                    کردنەوەی ڕۆژمێر
                  </button>

                  <div className={`w-7 h-7 rounded-lg bg-gray-100 flex items-center justify-center transition-transform ${isExpanded ? 'rotate-90' : ''}`}>
                    <ChevronLeft className="w-4 h-4 text-gray-600" />
                  </div>
                </div>
              </div>

              {/* Expanded Employee Roster */}
              {isExpanded && (
                <div className="p-4 bg-[#fbfbfa] border-t border-[#e4e6df] space-y-3">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-xs font-bold text-[#6b7268]">
                      لیستی کارمەندانی بەشی {dept.name}:
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onOpenAddEmployeeForDept(dept.id)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#dbd80f] hover:bg-[#c2be0d] text-[#2c2c00] text-xs font-bold rounded-lg transition"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>زیادکردنی کارمەند</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onOpenBulkAddForDept(dept.id)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-[#e4e6df] hover:bg-gray-50 text-[#1f2420] text-xs font-semibold rounded-lg transition"
                      >
                        <FileCode className="w-3.5 h-3.5 text-indigo-600" />
                        <span>هاوردەی JSON</span>
                      </button>
                    </div>
                  </div>

                  {filteredEmps.length === 0 ? (
                    <div className="py-6 text-center text-xs text-[#6b7268]">
                      هیچ کارمەندێک بۆ ئەم بەشە نییە.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {filteredEmps.map((emp) => (
                        <div
                          key={emp.id}
                          className="p-3 bg-white border border-[#e4e6df] rounded-xl flex items-center justify-between gap-2 shadow-2xs hover:border-gray-400 transition"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-[#f0f2eb] text-[#1f2420] flex items-center justify-center font-bold text-xs">
                              {emp.name.slice(0, 1)}
                            </div>
                            <div>
                              <div className="font-bold text-xs text-[#1f2420]">{emp.name}</div>
                              <div className="text-[11px] text-[#6b7268] flex items-center gap-1.5 mt-0.5">
                                <span className="font-mono">#{emp.empCode}</span>
                                <span>•</span>
                                <span>شەفتی {emp.shiftType}</span>
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => onOpenEditEmployee(emp.id)}
                            className="px-2.5 py-1 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg text-xs font-medium text-gray-700 transition"
                          >
                            دەستکاری
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
